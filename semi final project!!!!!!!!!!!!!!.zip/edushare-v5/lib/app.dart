import 'dart:io';
import 'dart:typed_data';
import 'dart:math';

import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:table_calendar/table_calendar.dart';

const kPrimaryRose = Color(0xFFA45C5C);

class Course {
  const Course({
    required this.id,
    required this.name,
    required this.description,
    required this.teacherId,
    this.enrolledStudents = const [],
  });

  final String id;
  final String name;
  final String description;
  final String teacherId;
  final List<String> enrolledStudents;

  Course copyWith({
    String? id,
    String? name,
    String? description,
    String? teacherId,
    List<String>? enrolledStudents,
  }) {
    return Course(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      teacherId: teacherId ?? this.teacherId,
      enrolledStudents: enrolledStudents ?? this.enrolledStudents,
    );
  }
}

class EduUser {
  const EduUser({
    required this.username,
    required this.password,
    required this.role,
    required this.fullName,
    required this.email,
    required this.bio,
    this.avatarBytes,
    this.enrolledCourses = const [],
    this.gender = '',
    this.birthday = '',
    this.address = '',
  });

  final String username;
  final String password;
  final String role;
  final String fullName;
  final String email;
  final String bio;
  final Uint8List? avatarBytes;
  final List<String> enrolledCourses;
  final String gender;
  final String birthday;
  final String address;

  EduUser copyWith({
    String? username,
    String? password,
    String? role,
    String? fullName,
    String? email,
    String? bio,
    Uint8List? avatarBytes,
    bool clearAvatar = false,
    List<String>? enrolledCourses,
    String? gender,
    String? birthday,
    String? address,
  }) {
    return EduUser(
      username: username ?? this.username,
      password: password ?? this.password,
      role: role ?? this.role,
      fullName: fullName ?? this.fullName,
      email: email ?? this.email,
      bio: bio ?? this.bio,
      avatarBytes: clearAvatar ? null : (avatarBytes ?? this.avatarBytes),
      enrolledCourses: enrolledCourses ?? this.enrolledCourses,
      gender: gender ?? this.gender,
      birthday: birthday ?? this.birthday,
      address: address ?? this.address,
    );
  }
}

class ChatMessage {
  const ChatMessage({
    required this.sender,
    required this.content,
    required this.time,
    required this.courseId,
    this.attachmentPath,
    this.attachmentName,
    this.attachmentKind,
    this.attachmentBytes,
  });

  final String sender;
  final String content;
  final DateTime time;
  final String courseId;
  final String? attachmentPath;
  final String? attachmentName;
  final ChatAttachmentKind? attachmentKind;
  final Uint8List? attachmentBytes;
}

enum ChatAttachmentKind { image, file }

class ChatRoom {
  const ChatRoom({
    required this.id,
    required this.name,
    required this.type,
    required this.courseId,
    this.participants = const [],
    this.lastMessage,
    this.createdAt,
  });

  final String id;
  final String name;
  final ChatRoomType type;
  final String courseId;
  final List<String> participants; // usernames
  final ChatMessage? lastMessage;
  final DateTime? createdAt;

  ChatRoom copyWith({
    String? id,
    String? name,
    ChatRoomType? type,
    String? courseId,
    List<String>? participants,
    ChatMessage? lastMessage,
    DateTime? createdAt,
  }) {
    return ChatRoom(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      courseId: courseId ?? this.courseId,
      participants: participants ?? this.participants,
      lastMessage: lastMessage ?? this.lastMessage,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

enum ChatRoomType { group, direct }

class LessonPlan {
  const LessonPlan({
    required this.title,
    required this.description,
    required this.date,
    required this.createdBy,
    required this.courseId,
  });

  final String title;
  final String description;
  final DateTime date;
  final String createdBy;
  final String courseId;
}

class TodoItem {
  const TodoItem({
    required this.title, 
    this.isDone = false, 
    required this.userId,
    required this.courseId,
  });

  final String title;
  final bool isDone;
  final String userId;
  final String courseId;

  TodoItem copyWith({String? title, bool? isDone, String? userId, String? courseId}) {
    return TodoItem(
      title: title ?? this.title, 
      isDone: isDone ?? this.isDone,
      userId: userId ?? this.userId,
      courseId: courseId ?? this.courseId,
    );
  }
}

class CalendarEvent {
  const CalendarEvent({
    required this.title,
    required this.description,
    required this.date,
    required this.userId,
    required this.courseId,
  });

  final String title;
  final String description;
  final DateTime date;
  final String userId;
  final String courseId;

  CalendarEvent copyWith({String? title, String? description, DateTime? date, String? userId, String? courseId}) {
    return CalendarEvent(
      title: title ?? this.title,
      description: description ?? this.description,
      date: date ?? this.date,
      userId: userId ?? this.userId,
      courseId: courseId ?? this.courseId,
    );
  }
}

class NoteTransaction {
  const NoteTransaction({
    required this.id,
    required this.lessonTitle,
    required this.courseName,
    required this.sharedBy,
    required this.sharedWith,
    required this.time,
    required this.direction, // 'sent' or 'received'
  });

  final String id;
  final String lessonTitle;
  final String courseName;
  final String sharedBy;
  final String sharedWith;
  final DateTime time;
  final String direction;
}

class Announcement {
  const Announcement({
    required this.title,
    required this.content,
    required this.date,
    required this.createdBy,
    required this.courseId,
    this.isPinned = false,
  });

  final String title;
  final String content;
  final DateTime date;
  final String createdBy;
  final String courseId;
  final bool isPinned;

  Announcement copyWith({
    String? title,
    String? content,
    DateTime? date,
    String? createdBy,
    String? courseId,
    bool? isPinned,
  }) {
    return Announcement(
      title: title ?? this.title,
      content: content ?? this.content,
      date: date ?? this.date,
      createdBy: createdBy ?? this.createdBy,
      courseId: courseId ?? this.courseId,
      isPinned: isPinned ?? this.isPinned,
    );
  }
}

class LibraryItem {
  const LibraryItem({
    required this.id,
    required this.title,
    required this.content,
    required this.createdBy,
    required this.courseId,
    this.color = 0xFFA45C5C,
    this.fontFamily = 'AlegreyaSC',
    this.backgroundColor = 0xFFFFFAF0,
    this.isMarkedAsToD = false,
  });

  final String id;
  final String title;
  final String content;
  final String createdBy;
  final String courseId;
  final int color;
  final String fontFamily;
  final int backgroundColor;
  final bool isMarkedAsToD;

  LibraryItem copyWith({
    String? id,
    String? title,
    String? content,
    String? createdBy,
    String? courseId,
    int? color,
    String? fontFamily,
    int? backgroundColor,
    bool? isMarkedAsToD,
  }) {
    return LibraryItem(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      createdBy: createdBy ?? this.createdBy,
      courseId: courseId ?? this.courseId,
      color: color ?? this.color,
      fontFamily: fontFamily ?? this.fontFamily,
      backgroundColor: backgroundColor ?? this.backgroundColor,
      isMarkedAsToD: isMarkedAsToD ?? this.isMarkedAsToD,
    );
  }
}

class EduShareApp extends StatefulWidget {
  const EduShareApp({super.key});

  @override
  State<EduShareApp> createState() => _EduShareAppState();
}

class _EduShareAppState extends State<EduShareApp> {
  final List<EduUser> _users = [];
  final List<NoteTransaction> _noteTransactions = [];
  final List<ChatMessage> _messages = [];
  final List<ChatRoom> _chatRooms = [];
  final List<LessonPlan> _lessonPlans = [];
  final List<CalendarEvent> _events = [];
  final List<TodoItem> _todos = [];
  final List<Announcement> _announcements = [];

  // Pre-loaded default courses visible to all students
  final List<Course> _courses = [
    Course(
      id: 'course_appsdev',
      name: 'APPSDEV',
      description: 'Application Development',
      teacherId: 'system',
      enrolledStudents: [],
    ),
    Course(
      id: 'course_platech22',
      name: 'PLATECH22',
      description: 'Platform Technologies 2022',
      teacherId: 'system',
      enrolledStudents: [],
    ),
    Course(
      id: 'course_datastruc22',
      name: 'DATASTRUC22',
      description: 'Data Structures 2022',
      teacherId: 'system',
      enrolledStudents: [],
    ),
    Course(
      id: 'course_datacomm',
      name: 'DATACOMM',
      description: 'Data Communications',
      teacherId: 'system',
      enrolledStudents: [],
    ),
    Course(
      id: 'course_socio102',
      name: 'SOCIO102',
      description: 'Sociology 102',
      teacherId: 'system',
      enrolledStudents: [],
    ),
    Course(
      id: 'course_philo101',
      name: 'PHILO101',
      description: 'Philosophy 101',
      teacherId: 'system',
      enrolledStudents: [],
    ),
  ];

  final List<LibraryItem> _libraryItems = [
    // APPSDEV
    LibraryItem(
      id: 'lib_appsdev_1',
      title: 'Lesson 1',
      content: 'Application Development is a software designed to help a user perform a specific task (like EDUshare helps students).\n\nThe App Lifecycle (SDLC)\n\n• Plan: Decide what the app does.\n• Design: Create the look and feel (UI/UX).\n• Build: Write the code.\n• Test: Fix any bugs or glitches.\n• Launch: Release it to the users.\n\nTwo Ways to Build\n\n• Waterfall: Step-by-step. You can\'t go back once a stage is done.\n• Agile: Fast and flexible. You build, get feedback, and improve as you go.\n\nApplication Development is a software designed to help a user perform a specific task (like EDUshare helps students).\n\nThe App Lifecycle (SDLC)',
      createdBy: 'system',
      courseId: 'course_appsdev',
    ),
    // PLATECH22
    LibraryItem(
      id: 'lib_platech22_1',
      title: 'Lesson 1',
      content: 'Practical Technology (Platech) – subject about using technology in real-life tasks\n\nTypes of Platech:\n\n• Industrial Technology – machines and production work\n\n• Information Technology – computers and software\n\n• Communication Technology – sending and receiving information\n\n• Agricultural Technology – farming tools and methods\n\n• Home Technology – tools for daily household use',
      createdBy: 'system',
      courseId: 'course_platech22',
    ),
    // DATASTRUC22
    LibraryItem(
      id: 'lib_datastruc22_1',
      title: 'Lesson 1',
      content: 'Data structure is a way of organizing data so it can be used easily and quickly in a program. It helps make storing, finding, and updating data more efficient.\n\nMain types of data structures:\n\n• Linear – data is arranged in a straight order (array, list, stack, queue)\n\n• Non-linear – data is connected in different ways (tree, graph)',
      createdBy: 'system',
      courseId: 'course_datastruc22',
    ),
    // DATACOMM
    LibraryItem(
      id: 'lib_datacomm_1',
      title: 'Lesson 1',
      content: 'Data communication is the process of sending and receiving data between devices through a transmission medium like cables or wireless signals. It allows devices to share information quickly and efficiently.\n\nTypes of data communication:\n\n• Simplex – one-way communication only\n\n• Half-duplex – both devices can send and receive, but not at the same time\n\n• Full-duplex – both devices can send and receive at the same time',
      createdBy: 'system',
      courseId: 'course_datacomm',
    ),
    // SOCIO102
    LibraryItem(
      id: 'lib_socio102_1',
      title: 'Lesson 1',
      content: 'Socio (short for social) refers to how people interact, behave, and relate with others in society. It focuses on relationships, communication, and social roles.\n\nTypes of social interaction:\n\n• Cooperation – working together to achieve a goal\n\n• Competition – trying to achieve a goal over others\n\n• Conflict – disagreement or clash between individuals or groups\n\n• Accommodation – adjusting to maintain peace and order',
      createdBy: 'system',
      courseId: 'course_socio102',
    ),
    // PHILO101
    LibraryItem(
      id: 'lib_philo101_1',
      title: 'Lesson 1',
      content: 'Philo 101 (Introduction to Philosophy) is the study of basic questions about life, knowledge, truth, and existence. It helps develop critical thinking, reasoning, and understanding of different ideas.\n\nMain branches of philosophy:\n\n• Metaphysics – study of reality and existence\n\n• Epistemology – study of knowledge and truth\n\n• Ethics – study of right and wrong\n\n• Logic – study of correct reasoning',
      createdBy: 'system',
      courseId: 'course_philo101',
    ),
  ];

  EduUser? _currentUser;
  String? _selectedCourseId;

  bool login(String username, String password) {
    final match = _users.where(
      (user) => user.username == username && user.password == password,
    );
    if (match.isEmpty) return false;
    setState(() {
      _currentUser = match.first;
      // Auto-select the first available course
      if (_selectedCourseId == null && _courses.isNotEmpty) {
        _selectedCourseId = _courses.first.id;
      }
    });
    return true;
  }

  String? register({
    required String username,
    required String password,
    required String role,
    required String fullName,
    required String email,
  }) {
    if (_users.any((u) => u.username == username)) {
      return 'Username already exists.';
    }
    setState(() {
      _users.add(
        EduUser(
          username: username,
          password: password,
          role: role,
          fullName: fullName,
          email: email,
          bio: 'New to EduShare. Ready to learn and collaborate.',
        ),
      );
    });
    return null;
  }

  void logout() => setState(() => _currentUser = null);

  void deleteAccount() {
    if (_currentUser == null) return;
    final username = _currentUser!.username;
    setState(() {
      _users.removeWhere((u) => u.username == username);
      _currentUser = null;
    });
  }

  bool resetPassword(String email, String newPassword) {
    // Find user by email
    final userIndex = _users.indexWhere((u) => u.email == email);
    if (userIndex == -1) return false;
    
    // Update user password
    setState(() {
      _users[userIndex] = _users[userIndex].copyWith(password: newPassword);
    });
    
    return true;
  }

  void addMessage(String text, String courseId) {
    if (_currentUser == null || text.trim().isEmpty) return;
    if (_selectedCourseId == null) return;
    setState(() {
      _messages.add(
        ChatMessage(
          sender: _currentUser!.fullName,
          content: text.trim(),
          time: DateTime.now(),
          courseId: courseId,
        ),
      );
    });
  }

  void addAttachmentMessage({
    required String caption,
    required ChatAttachmentKind kind,
    required String path,
    required String name,
    Uint8List? bytes,
    required String courseId,
  }) {
    if (_currentUser == null) return;
    if (_selectedCourseId == null) return;
    setState(() {
      _messages.add(
        ChatMessage(
          sender: _currentUser!.fullName,
          content: caption.trim(),
          time: DateTime.now(),
          courseId: courseId,
          attachmentKind: kind,
          attachmentPath: path,
          attachmentName: name,
          attachmentBytes: bytes,
        ),
      );
    });
  }

  void addAttachmentMessageToRoom({
    required String caption,
    required ChatAttachmentKind kind,
    required String path,
    required String name,
    Uint8List? bytes,
    required String roomId,
  }) {
    if (_currentUser == null) return;
    setState(() {
      _messages.add(
        ChatMessage(
          sender: _currentUser!.fullName,
          content: caption.trim(),
          time: DateTime.now(),
          courseId: roomId, // Using roomId as courseId for room-specific messages
          attachmentKind: kind,
          attachmentPath: path,
          attachmentName: name,
          attachmentBytes: bytes,
        ),
      );
      
      // Update room's last message
      final roomIndex = _chatRooms.indexWhere((room) => room.id == roomId);
      if (roomIndex != -1) {
        _chatRooms[roomIndex] = _chatRooms[roomIndex].copyWith(
          lastMessage: _messages.last,
        );
      }
    });
  }

  void deleteMessage(int index) {
    if (index >= 0 && index < _messages.length) {
      setState(() => _messages.removeAt(index));
    }
  }

  // Chat room management methods
  void createGroupChat(String name, String courseId) {
    if (_currentUser?.role != 'Student') return;
    if (name.trim().isEmpty) return;
    
    final roomId = 'room_${DateTime.now().millisecondsSinceEpoch}';
    setState(() {
      _chatRooms.add(
        ChatRoom(
          id: roomId,
          name: name.trim(),
          type: ChatRoomType.group,
          courseId: _selectedCourseId ?? courseId, // Use selected course ID or fallback
          participants: [_currentUser!.username],
          createdAt: DateTime.now(),
        ),
      );
    });
  }

  void createDirectMessage(String otherUsername, String courseId) {
    if (_currentUser?.role != 'Student') return;
    if (otherUsername == _currentUser!.username) return;
    
    // Check if DM already exists (without course restriction)
    final existingDm = _chatRooms.where((room) =>
      room.type == ChatRoomType.direct &&
      room.participants.contains(_currentUser!.username) &&
      room.participants.contains(otherUsername)
    ).firstOrNull;
    
    if (existingDm != null) return;
    
    final roomId = 'dm_${DateTime.now().millisecondsSinceEpoch}';
    // Store both usernames so each participant can resolve the OTHER person's name
    final dmName = '${_currentUser!.username}|$otherUsername';
    setState(() {
      _chatRooms.add(
        ChatRoom(
          id: roomId,
          name: dmName,
          type: ChatRoomType.direct,
          // Use 'dm_global' so DMs are visible to both sides regardless of selected course
          courseId: 'dm_global',
          participants: [_currentUser!.username, otherUsername],
          createdAt: DateTime.now(),
        ),
      );
    });
  }

  void addMessageToRoom(String text, String roomId) {
    if (_currentUser == null || text.trim().isEmpty) return;
    setState(() {
      _messages.add(
        ChatMessage(
          sender: _currentUser!.fullName,
          content: text.trim(),
          time: DateTime.now(),
          courseId: roomId, // Using roomId as courseId for room-specific messages
        ),
      );
      
      // Update room's last message
      final roomIndex = _chatRooms.indexWhere((room) => room.id == roomId);
      if (roomIndex != -1) {
        _chatRooms[roomIndex] = _chatRooms[roomIndex].copyWith(
          lastMessage: _messages.last,
        );
      }
    });
  }

  List<ChatRoom> getAvailableChatRooms() {
    if (_currentUser?.role != 'Student') return [];
    
    return _chatRooms.where((room) {
      if (!room.participants.contains(_currentUser!.username)) return false;
      // DMs are always visible regardless of selected course
      if (room.type == ChatRoomType.direct) return true;
      // Group chats are scoped to the selected course
      return _selectedCourseId != null && room.courseId == _selectedCourseId;
    }).toList();
  }

  List<EduUser> getAvailableStudentsForDM() {
    if (_currentUser?.role != 'Student') return [];
    
    // Get all students (temporarily removing course restriction for testing)
    return _users.where((user) =>
      user.role == 'Student' &&
      user.username != _currentUser!.username
    ).toList();
  }

  void addParticipantToGroup(String roomId, String username) {
    if (_currentUser?.role != 'Student') return;
    if (username == _currentUser!.username) return;
    
    final roomIndex = _chatRooms.indexWhere((room) => room.id == roomId);
    if (roomIndex == -1) return;
    
    final room = _chatRooms[roomIndex];
    if (room.type != ChatRoomType.group) return;
    if (room.participants.contains(username)) return;
    
    setState(() {
      _chatRooms[roomIndex] = room.copyWith(
        participants: [...room.participants, username],
      );
    });
  }

  void addLessonPlan(String title, String description, DateTime date, String courseId) {
    if (_currentUser?.role != 'Teacher') return;
    if (title.trim().isEmpty || description.trim().isEmpty) return;
    if (_selectedCourseId == null) return;
    setState(() {
      _lessonPlans.add(
        LessonPlan(
          title: title.trim(),
          description: description.trim(),
          date: date,
          createdBy: _currentUser!.fullName,
          courseId: courseId,
        ),
      );
    });
  }

  void updateLessonPlan(
    int index,
    String title,
    String description,
    DateTime date,
  ) {
    if (_currentUser?.role != 'Teacher') return;
    if (index < 0 || index >= _lessonPlans.length) return;
    final current = _lessonPlans[index];
    setState(() {
      _lessonPlans[index] = LessonPlan(
        title: title.trim(),
        description: description.trim(),
        date: date,
        createdBy: current.createdBy,
        courseId: current.courseId, // Preserve the original courseId
      );
    });
  }

  void deleteLessonPlan(int index) {
    if (_currentUser?.role == 'Teacher' &&
        index >= 0 &&
        index < _lessonPlans.length) {
      setState(() => _lessonPlans.removeAt(index));
    }
  }

  void addAnnouncement(String title, String content, String courseId, {bool isPinned = false}) {
    if (_currentUser?.role != 'Teacher') return;
    if (title.trim().isEmpty || content.trim().isEmpty) return;
    if (_selectedCourseId == null) return;
    setState(() {
      _announcements.add(
        Announcement(
          title: title.trim(),
          content: content.trim(),
          date: DateTime.now(),
          createdBy: _currentUser!.username,
          courseId: courseId,
          isPinned: isPinned,
        ),
      );
      // Sort announcements: pinned first, then by date (newest first)
      _announcements.sort((a, b) {
        if (a.isPinned != b.isPinned) {
          return b.isPinned ? 1 : -1;
        }
        return b.date.compareTo(a.date);
      });
    });
  }

  void updateAnnouncement(int index, String title, String content, {bool? isPinned}) {
    if (_currentUser?.role != 'Teacher') return;
    if (index < 0 || index >= _announcements.length) return;
    setState(() {
      _announcements[index] = _announcements[index].copyWith(
        title: title.trim(),
        content: content.trim(),
        courseId: _announcements[index].courseId, // Preserve the original courseId
        isPinned: isPinned ?? _announcements[index].isPinned,
      );
      // Re-sort after update
      _announcements.sort((a, b) {
        if (a.isPinned != b.isPinned) {
          return b.isPinned ? 1 : -1;
        }
        return b.date.compareTo(a.date);
      });
    });
  }

  void deleteAnnouncement(int index) {
    if (_currentUser?.role != 'Teacher') return;
    if (index >= 0 && index < _announcements.length) {
      setState(() => _announcements.removeAt(index));
    }
  }

  // Library management functions
  void addLibraryItem(String title, String content) {
    if (_currentUser == null || title.trim().isEmpty || content.trim().isEmpty) return;
    if (_selectedCourseId == null) return;
    
    final itemId = 'lib_${DateTime.now().millisecondsSinceEpoch}';
    setState(() {
      _libraryItems.add(
        LibraryItem(
          id: itemId,
          title: title.trim(),
          content: content.trim(),
          createdBy: _currentUser!.username,
          courseId: _selectedCourseId!,
        ),
      );
    });
  }

  void updateLibraryItem(int index, {String? title, String? content, int? color, String? fontFamily, int? backgroundColor}) {
    if (index < 0 || index >= _libraryItems.length) return;
    setState(() {
      _libraryItems[index] = _libraryItems[index].copyWith(
        title: title ?? _libraryItems[index].title,
        content: content ?? _libraryItems[index].content,
        color: color ?? _libraryItems[index].color,
        fontFamily: fontFamily ?? _libraryItems[index].fontFamily,
        backgroundColor: backgroundColor ?? _libraryItems[index].backgroundColor,
      );
    });
  }

  void toggleLibraryItemToDo(int index) {
    if (index < 0 || index >= _libraryItems.length) return;
    setState(() {
      _libraryItems[index] = _libraryItems[index].copyWith(
        isMarkedAsToD: !_libraryItems[index].isMarkedAsToD,
      );
    });
  }

  void deleteLibraryItem(int index) {
    if (index >= 0 && index < _libraryItems.length) {
      setState(() => _libraryItems.removeAt(index));
    }
  }

  void shareLibraryItemToRoom(LibraryItem item, String roomId) {
    if (_currentUser == null) return;
    final shareText = '📚 Library Item Shared:\n'
        '${item.title}\n\n'
        '${item.content}';
    addMessageToRoom(shareText, roomId);
  }

  void shareLessonFromChat(LibraryItem item, String roomId, String recipientDisplayName) {
    if (_currentUser == null) return;
    final course = _courses.firstWhere(
      (c) => c.id == item.courseId,
      orElse: () => Course(id: '', name: item.courseId, description: '', teacherId: ''),
    );
    final shareText = '📚 Shared lesson: ${item.title} (${course.name})\n\n${item.content}';
    addMessageToRoom(shareText, roomId);
    setState(() {
      _noteTransactions.insert(
        0,
        NoteTransaction(
          id: 'txn_${DateTime.now().millisecondsSinceEpoch}',
          lessonTitle: item.title,
          courseName: course.name,
          sharedBy: _currentUser!.fullName,
          sharedWith: recipientDisplayName,
          time: DateTime.now(),
          direction: 'sent',
        ),
      );
    });
  }

  // Course management functions
  void createCourse(String name, String description) {
    if (_currentUser?.role != 'Teacher') return;
    if (name.trim().isEmpty || description.trim().isEmpty) return;
    
    final courseId = 'course_${DateTime.now().millisecondsSinceEpoch}';
    setState(() {
      _courses.add(
        Course(
          id: courseId,
          name: name.trim(),
          description: description.trim(),
          teacherId: _currentUser!.username,
        ),
      );
      // Auto-select the newly created course for the teacher
      _selectedCourseId = courseId;
      // Add course to teacher's enrolled courses
      _currentUser = _currentUser!.copyWith(
        enrolledCourses: [..._currentUser!.enrolledCourses, courseId]
      );
    });
  }

  void enrollInCourse(String courseId) {
    if (_currentUser == null) return;
    if (_currentUser!.role != 'Student') return;
    if (_currentUser!.enrolledCourses.contains(courseId)) return;
    
    setState(() {
      // Add course to student's enrolled courses
      _currentUser = _currentUser!.copyWith(
        enrolledCourses: [..._currentUser!.enrolledCourses, courseId]
      );
      // Add student to course's enrolled students
      final courseIndex = _courses.indexWhere((c) => c.id == courseId);
      if (courseIndex != -1) {
        _courses[courseIndex] = _courses[courseIndex].copyWith(
          enrolledStudents: [..._courses[courseIndex].enrolledStudents, _currentUser!.username]
        );
      }
      // Auto-select the enrolled course
      _selectedCourseId = courseId;
    });
  }

  void selectCourse(String? courseId) {
    setState(() => _selectedCourseId = courseId);
  }

  void renameCourse(String courseId, String newName) {
    if (newName.trim().isEmpty) return;
    final i = _courses.indexWhere((c) => c.id == courseId);
    if (i == -1) return;
    setState(() {
      _courses[i] = _courses[i].copyWith(name: newName.trim());
    });
  }

  void deleteCourse(String courseId) {
    setState(() {
      _courses.removeWhere((c) => c.id == courseId);
      _libraryItems.removeWhere((item) => item.courseId == courseId);
      if (_selectedCourseId == courseId) _selectedCourseId = null;
      if (_currentUser != null) {
        _currentUser = _currentUser!.copyWith(
          enrolledCourses: _currentUser!.enrolledCourses
              .where((id) => id != courseId)
              .toList(),
        );
      }
    });
  }

  void addCustomCourse(String name) {
    if (name.trim().isEmpty) return;
    final courseId = 'course_custom_${DateTime.now().millisecondsSinceEpoch}';
    setState(() {
      _courses.add(Course(
        id: courseId,
        name: name.trim(),
        description: name.trim(),
        teacherId: _currentUser?.username ?? 'user',
      ));
      if (_currentUser != null) {
        _currentUser = _currentUser!.copyWith(
          enrolledCourses: [..._currentUser!.enrolledCourses, courseId],
        );
      }
    });
  }

  void addLibraryItemToCourse(String title, String content, String courseId) {
    if (title.trim().isEmpty || content.trim().isEmpty) return;
    final itemId = 'lib_${DateTime.now().millisecondsSinceEpoch}';
    setState(() {
      _libraryItems.add(LibraryItem(
        id: itemId,
        title: title.trim(),
        content: content.trim(),
        createdBy: _currentUser?.username ?? 'user',
        courseId: courseId,
      ));
    });
  }

  List<Course> getAvailableCoursesForUser() {
    if (_currentUser == null) return [];
    // Show all courses to everyone — teachers see their own + system courses, students see all
    return _courses;
  }

  List<Course> getAvailableCoursesForEnrollment() {
    if (_currentUser?.role != 'Student') return [];
    // Students can see all courses for enrollment (except ones they're already in)
    return _courses.where((c) => !_currentUser!.enrolledCourses.contains(c.id)).toList();
  }

  void addTodo(String title, String courseId) {
    if (_currentUser == null) return;
    if (title.trim().isEmpty) return;
    if (_selectedCourseId == null) return;
    setState(() => _todos.add(TodoItem(
      title: title.trim(), 
      userId: _currentUser!.username,
      courseId: courseId,
    )));
  }

  void toggleTodo(int index) {
    if (index < 0 || index >= _todos.length) return;
    setState(() {
      _todos[index] = _todos[index].copyWith(
        isDone: !_todos[index].isDone,
        userId: _todos[index].userId, // Preserve the original userId
        courseId: _todos[index].courseId, // Preserve the original courseId
      );
    });
  }

  void editTodo(int index, String title) {
    if (index < 0 || index >= _todos.length || title.trim().isEmpty) return;
    setState(() {
      _todos[index] = _todos[index].copyWith(
        title: title.trim(),
        userId: _todos[index].userId, // Preserve the original userId
        courseId: _todos[index].courseId, // Preserve the original courseId
      );
    });
  }

  void deleteTodo(int index) {
    if (index >= 0 && index < _todos.length) {
      setState(() => _todos.removeAt(index));
    }
  }

  void addEvent(String title, String description, DateTime date, String courseId) {
    if (_currentUser == null) return;
    if (title.trim().isEmpty || description.trim().isEmpty) return;
    if (_selectedCourseId == null) return;
    setState(() {
      _events.add(
        CalendarEvent(
          title: title.trim(),
          description: description.trim(),
          date: date,
          userId: _currentUser!.username,
          courseId: courseId,
        ),
      );
    });
  }

  void updateEvent(int index, String title, String description, DateTime date) {
    if (index < 0 || index >= _events.length) return;
    setState(() {
      _events[index] = _events[index].copyWith(
        title: title.trim(),
        description: description.trim(),
        date: date,
        userId: _events[index].userId, // Preserve the original userId
        courseId: _events[index].courseId, // Preserve the original courseId
      );
    });
  }

  void deleteEvent(int index) {
    if (index >= 0 && index < _events.length) {
      setState(() => _events.removeAt(index));
    }
  }

  void updateProfile({
    required String fullName,
    required String email,
    required String bio,
    Uint8List? avatarBytes,
    String? gender,
    String? birthday,
    String? address,
  }) {
    if (_currentUser == null) return;
    final index = _users.indexWhere(
      (u) => u.username == _currentUser!.username,
    );
    if (index == -1) return;
    final updated = _currentUser!.copyWith(
      fullName: fullName.trim(),
      email: email.trim(),
      bio: bio.trim(),
      avatarBytes: avatarBytes,
      gender: gender ?? _currentUser!.gender,
      birthday: birthday ?? _currentUser!.birthday,
      address: address ?? _currentUser!.address,
    );
    setState(() {
      _users[index] = updated;
      _currentUser = updated;
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = _currentUser;
    final courseId = _selectedCourseId;
    final filteredLibraryItems = user != null && courseId != null
        ? _libraryItems
            .where((item) => item.courseId == courseId && (item.createdBy == user.username || item.createdBy == 'system'))
            .toList()
        : <LibraryItem>[];

    int? libraryLocalIndexToGlobal(int localIndex) {
      if (localIndex < 0 || localIndex >= filteredLibraryItems.length) return null;
      final id = filteredLibraryItems[localIndex].id;
      final global = _libraryItems.indexWhere((e) => e.id == id);
      return global >= 0 ? global : null;
    }

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'EduShare',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: kPrimaryRose),
        appBarTheme: const AppBarTheme(
          backgroundColor: kPrimaryRose,
          foregroundColor: Colors.white,
        ),
      ),
      home: _currentUser == null
          ? AuthScreen(onLogin: login, onRegister: register, onPasswordReset: resetPassword)
          : HomeScreen(
              currentUser: _currentUser!,
              messages: _messages,
              lessonPlans: _selectedCourseId != null 
                  ? _lessonPlans.where((plan) => plan.courseId == _selectedCourseId).toList()
                  : [],
              todos: _selectedCourseId != null 
                  ? _todos.where((todo) => todo.userId == _currentUser!.username && todo.courseId == _selectedCourseId).toList()
                  : [],
              events: _selectedCourseId != null 
                  ? _events.where((event) => event.userId == _currentUser!.username && event.courseId == _selectedCourseId).toList()
                  : [],
              announcements: _selectedCourseId != null 
                  ? _announcements.where((announcement) => announcement.courseId == _selectedCourseId).toList()
                  : [],
              libraryItems: filteredLibraryItems,
              allLibraryItems: user != null ? _libraryItems.where((item) => item.createdBy == user.username || item.createdBy == 'system').toList() : [],
              onLogout: logout,
              onDeleteAccount: deleteAccount,
              onSendMessage: (text) => _selectedCourseId != null ? addMessage(text, _selectedCourseId!) : null,
              onSendAttachment: ({
                required caption,
                required kind,
                required path,
                required name,
                bytes,
              }) => _selectedCourseId != null ? addAttachmentMessage(
                caption: caption,
                kind: kind,
                path: path,
                name: name,
                bytes: bytes,
                courseId: _selectedCourseId!,
              ) : null,
              onDeleteMessage: deleteMessage,
              onCreateLessonPlan: (title, description, date) => _selectedCourseId != null ? addLessonPlan(title, description, date, _selectedCourseId!) : null,
              onUpdateLessonPlan: updateLessonPlan,
              onDeleteLessonPlan: deleteLessonPlan,
              onAddTodo: (title) => _selectedCourseId != null ? addTodo(title, _selectedCourseId!) : null,
              onToggleTodo: toggleTodo,
              onEditTodo: editTodo,
              onDeleteTodo: deleteTodo,
              onAddEvent: (title, description, date) => _selectedCourseId != null ? addEvent(title, description, date, _selectedCourseId!) : null,
              onUpdateEvent: updateEvent,
              onDeleteEvent: deleteEvent,
              onUpdateProfile: updateProfile,
              onCreateAnnouncement: (title, content, {isPinned}) => _selectedCourseId != null ? addAnnouncement(title, content, _selectedCourseId!, isPinned: isPinned ?? false) : null,
              onUpdateAnnouncement: updateAnnouncement,
              onDeleteAnnouncement: deleteAnnouncement,
              onAddLibraryItem: (title, content) => _selectedCourseId != null ? addLibraryItem(title, content) : null,
              onUpdateLibraryItem: (localIndex, {title, content, color, fontFamily, backgroundColor}) {
                final g = libraryLocalIndexToGlobal(localIndex);
                if (g == null) return;
                updateLibraryItem(
                  g,
                  title: title,
                  content: content,
                  color: color,
                  fontFamily: fontFamily,
                  backgroundColor: backgroundColor,
                );
              },
              onToggleLibraryItemToDo: (localIndex) {
                final g = libraryLocalIndexToGlobal(localIndex);
                if (g == null) return;
                toggleLibraryItemToDo(g);
              },
              onDeleteLibraryItem: (localIndex) {
                final g = libraryLocalIndexToGlobal(localIndex);
                if (g == null) return;
                deleteLibraryItem(g);
              },
              onShareLibraryItemToRoom: shareLibraryItemToRoom,
              courses: getAvailableCoursesForUser(),
              selectedCourseId: _selectedCourseId,
              onCreateCourse: createCourse,
              onEnrollInCourse: enrollInCourse,
              onSelectCourse: selectCourse,
              getAvailableCoursesForEnrollment: getAvailableCoursesForEnrollment,
              onRenameCourse: renameCourse,
              onDeleteCourse: deleteCourse,
              onAddCustomCourse: addCustomCourse,
              onAddLibraryItemToCourse: addLibraryItemToCourse,
              chatRooms: getAvailableChatRooms(),
              availableStudents: getAvailableStudentsForDM(),
              onCreateGroupChat: (name, courseId) => _selectedCourseId != null ? createGroupChat(name, _selectedCourseId!) : null,
              onCreateDirectMessage: (username, courseId) => _selectedCourseId != null ? createDirectMessage(username, _selectedCourseId!) : null,
              onSendMessageToRoom: (text, roomId) => addMessageToRoom(text, roomId),
              onAddParticipantToGroup: (roomId, username) => addParticipantToGroup(roomId, username),
              onSendAttachmentToRoom: ({
                required caption,
                required kind,
                required path,
                required name,
                bytes,
                required roomId,
              }) => addAttachmentMessageToRoom(
                caption: caption,
                kind: kind,
                path: path,
                name: name,
                bytes: bytes,
                roomId: roomId,
              ),
              onShareLessonToChat: (lesson) {
                if (_selectedCourseId != null) {
                  addMessage(
                    'Lesson Plan Shared:\n'
                    '${lesson.title}\n'
                    '${_formatDate(lesson.date)}\n'
                    '${lesson.description}',
                    _selectedCourseId!,
                  );
                }
              },
              noteTransactions: _noteTransactions,
              onShareLessonFromChat: shareLessonFromChat,
            ),
    );
  }
}

// Animated Gmail-style notification banner for OTP
class _GmailOtpNotification extends StatefulWidget {
  const _GmailOtpNotification({
    required this.email,
    required this.otp,
    required this.onDismiss,
  });

  final String email;
  final String otp;
  final VoidCallback onDismiss;

  @override
  State<_GmailOtpNotification> createState() => _GmailOtpNotificationState();
}

class _GmailOtpNotificationState extends State<_GmailOtpNotification>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _slideAnim;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 380),
    );
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, -1.2),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _fadeAnim = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _controller.forward();

    // Auto-dismiss after 7 seconds
    Future.delayed(const Duration(seconds: 7), () {
      if (mounted) _dismiss();
    });
  }

  void _dismiss() async {
    await _controller.reverse();
    widget.onDismiss();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Get the first name from email for the notification
    final name = widget.email.contains('@')
        ? widget.email.split('@').first.replaceAll('.', ' ')
        : widget.email;
    final displayName = name.isNotEmpty
        ? name[0].toUpperCase() + name.substring(1)
        : 'User';

    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: SlideTransition(
        position: _slideAnim,
        child: FadeTransition(
          opacity: _fadeAnim,
          child: GestureDetector(
            onTap: _dismiss,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: Material(
                  elevation: 8,
                  borderRadius: BorderRadius.circular(14),
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Gmail "M" icon
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            gradient: const LinearGradient(
                              colors: [Color(0xFF4285F4), Color(0xFFEA4335)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                          child: const Center(
                            child: Text(
                              'M',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'AlegreyaSC',
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'MAIL',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  color: Color(0xFF888888),
                                  letterSpacing: 1.2,
                                ),
                              ),
                              const SizedBox(height: 2),
                              RichText(
                                text: TextSpan(
                                  style: const TextStyle(
                                    fontSize: 13,
                                    color: Color(0xFF222222),
                                    height: 1.4,
                                  ),
                                  children: [
                                    TextSpan(
                                      text: 'Hi, $displayName! ',
                                      style: const TextStyle(fontWeight: FontWeight.w600),
                                    ),
                                    const TextSpan(
                                      text: 'Your verification code for EDUshare is ',
                                    ),
                                    TextSpan(
                                      text: widget.otp,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        color: Color(0xFFA45C5C),
                                      ),
                                    ),
                                    const TextSpan(
                                      text: '. Do not attempt to share this pin to anyone.',
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: _dismiss,
                          child: const Padding(
                            padding: EdgeInsets.only(left: 4),
                            child: Icon(Icons.close, size: 16, color: Color(0xFFAAAAAA)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// Rose-themed styled input field matching the design
class _RoseField extends StatelessWidget {
  const _RoseField({
    required this.controller,
    required this.hintText,
    required this.label,
    this.obscureText = false,
    this.keyboardType,
  });

  final TextEditingController controller;
  final String hintText;
  final String label;
  final bool obscureText;
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: Color(0xFF444444),
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          style: const TextStyle(color: Colors.white, fontSize: 14),
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 14),
            filled: true,
            fillColor: const Color(0xFFB07070),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Color(0xFFA45C5C), width: 2),
            ),
          ),
        ),
      ],
    );
  }
}

// Rose-themed button matching the design
class _RoseButton extends StatelessWidget {
  const _RoseButton({required this.label, required this.onPressed});

  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFA45C5C),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          elevation: 0,
        ),
        child: Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.3,
          ),
        ),
      ),
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({
    super.key,
    required this.onLogin,
    required this.onRegister,
    required this.onPasswordReset,
  });

  final bool Function(String username, String password) onLogin;
  final String? Function({
    required String username,
    required String password,
    required String role,
    required String fullName,
    required String email,
  })
  onRegister;
  final bool Function(String email, String newPassword) onPasswordReset;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool isLogin = true;
  String role = 'Student';
  bool isOtpVerification = false;
  bool isPasswordReset = false;
  String? generatedOtp;
  String? pendingUsername;
  String? pendingPassword;
  String? pendingRole;
  String? pendingFullName;
  String? pendingEmail;
  String? resetUsername;
  String? resetEmail;
  String? resetOtp;
  final loginUserCtrl = TextEditingController();
  final loginPassCtrl = TextEditingController();
  final regNameCtrl = TextEditingController();
  final regEmailCtrl = TextEditingController();
  final regUserCtrl = TextEditingController();
  final regPassCtrl = TextEditingController();
  final otpCtrl = TextEditingController();
  final forgotEmailCtrl = TextEditingController();
  final resetOtpCtrl = TextEditingController();
  final newPasswordCtrl = TextEditingController();

  OverlayEntry? _notifOverlay;

  @override
  void dispose() {
    _removeNotif();
    loginUserCtrl.dispose();
    loginPassCtrl.dispose();
    regNameCtrl.dispose();
    regEmailCtrl.dispose();
    regUserCtrl.dispose();
    regPassCtrl.dispose();
    otpCtrl.dispose();
    forgotEmailCtrl.dispose();
    resetOtpCtrl.dispose();
    newPasswordCtrl.dispose();
    super.dispose();
  }

  void _removeNotif() {
    _notifOverlay?.remove();
    _notifOverlay = null;
  }

  void _showGmailNotification(String email, String otp) {
    _removeNotif();
    final overlayState = Overlay.of(context);
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => _GmailOtpNotification(
        email: email,
        otp: otp,
        onDismiss: () {
          entry.remove();
          if (_notifOverlay == entry) _notifOverlay = null;
        },
      ),
    );
    _notifOverlay = entry;
    overlayState.insert(entry);
  }

  // OTP generation and validation methods
  String _generateOtp() {
    return (100000 + (Random().nextInt(900000))).toString();
  }

  void _sendOtpAndShowVerification() {
    final otp = _generateOtp();
    setState(() {
      generatedOtp = otp;
      isOtpVerification = true;
      pendingUsername = regUserCtrl.text.trim();
      pendingPassword = regPassCtrl.text.trim();
      pendingRole = role;
      pendingFullName = regNameCtrl.text.trim();
      pendingEmail = regEmailCtrl.text.trim();
    });
    _showGmailNotification(pendingEmail ?? '', otp);
  }

  void _verifyOtp() {
    final enteredOtp = otpCtrl.text.trim();
    if (enteredOtp.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter the OTP.')),
      );
      return;
    }
    
    if (enteredOtp == generatedOtp) {
      // OTP is correct, proceed with registration
      final error = widget.onRegister(
        username: pendingUsername!,
        password: pendingPassword!,
        role: pendingRole!,
        fullName: pendingFullName!,
        email: pendingEmail!,
      );
      
      if (error != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error)),
        );
        return;
      }
      
      // Registration successful, reset and switch to login
      final savedUsername = pendingUsername!;
      final savedPassword = pendingPassword!;
      setState(() {
        isOtpVerification = false;
        isLogin = true;
        generatedOtp = null;
        pendingUsername = null;
        pendingPassword = null;
        pendingRole = null;
        pendingFullName = null;
        pendingEmail = null;
        loginUserCtrl.text = savedUsername;
        loginPassCtrl.text = savedPassword;
        otpCtrl.clear();
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Account created successfully! Please sign in.')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid OTP. Please try again.')),
      );
    }
  }

  void _cancelOtpVerification() {
    setState(() {
      isOtpVerification = false;
      generatedOtp = null;
      pendingUsername = null;
      pendingPassword = null;
      pendingRole = null;
      pendingFullName = null;
      pendingEmail = null;
      otpCtrl.clear();
    });
  }

  void _resendOtp() {
    final newOtp = _generateOtp();
    setState(() {
      generatedOtp = newOtp;
    });
    _showGmailNotification(pendingEmail ?? '', newOtp);
  }

  // Forgot password functionality
  void _showForgotPasswordDialog() {
    forgotEmailCtrl.clear();
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Reset Password'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Enter your email address to receive a password reset code.'),
            const SizedBox(height: 16),
            TextField(
              controller: forgotEmailCtrl,
              decoration: const InputDecoration(
                labelText: 'Email Address',
                hintText: 'Enter your email',
              ),
              keyboardType: TextInputType.emailAddress,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => _sendPasswordResetOtp(dialogContext),
            child: const Text('Send Reset Code'),
          ),
        ],
      ),
    );
  }

  void _sendPasswordResetOtp(BuildContext dialogContext) {
    final email = forgotEmailCtrl.text.trim();
    if (email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your email address.')),
      );
      return;
    }
    
    if (!email.contains('@') || !email.contains('.')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid email address.')),
      );
      return;
    }
    
    // For demo purposes, we'll assume the email exists and send OTP
    final otp = _generateOtp();
    setState(() {
      resetOtp = otp;
      resetEmail = email;
      resetUsername = 'user'; // Will be validated during password reset
      isPasswordReset = true;
    });
    
    Navigator.pop(dialogContext);
    _showGmailNotification(email, otp);
  }

  void _verifyResetOtp() {
    final enteredOtp = resetOtpCtrl.text.trim();
    if (enteredOtp.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter the reset code.')),
      );
      return;
    }
    
    if (enteredOtp == resetOtp) {
      // OTP is correct, show password reset form
      _showNewPasswordDialog();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid reset code. Please try again.')),
      );
    }
  }

  void _showNewPasswordDialog() {
    newPasswordCtrl.clear();
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Set New Password'),
        content: TextField(
          controller: newPasswordCtrl,
          decoration: const InputDecoration(
            labelText: 'New Password',
            hintText: 'Enter your new password',
          ),
          obscureText: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => _resetPassword(dialogContext),
            child: const Text('Reset Password'),
          ),
        ],
      ),
    );
  }

  void _resetPassword(BuildContext dialogContext) {
    final newPassword = newPasswordCtrl.text.trim();
    if (newPassword.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a new password.')),
      );
      return;
    }
    
    if (newPassword.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password must be at least 6 characters long.')),
      );
      return;
    }
    
    // Use callback to reset password
    final success = widget.onPasswordReset(resetEmail!, newPassword);
    
    if (success) {
      Navigator.pop(dialogContext);
      
      // Reset password reset state
      setState(() {
        isPasswordReset = false;
        resetOtp = null;
        resetEmail = null;
        resetUsername = null;
        resetOtpCtrl.clear();
        newPasswordCtrl.clear();
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password reset successfully! Please sign in.')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to reset password. Please try again.')),
      );
    }
  }

  void _cancelPasswordReset() {
    setState(() {
      isPasswordReset = false;
      resetOtp = null;
      resetEmail = null;
      resetUsername = null;
      resetOtpCtrl.clear();
      newPasswordCtrl.clear();
    });
  }

  void _submit() {
    if (isLogin) {
      final ok = widget.onLogin(
        loginUserCtrl.text.trim(),
        loginPassCtrl.text.trim(),
      );
      if (!ok) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Invalid email or password.')),
        );
      }
      return;
    }
    if (regNameCtrl.text.trim().isEmpty ||
        regEmailCtrl.text.trim().isEmpty ||
        regPassCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please complete all fields.')),
      );
      return;
    }
    final email = regEmailCtrl.text.trim();
    if (!email.contains('@') || !email.contains('.')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid email address.')),
      );
      return;
    }
    // Use email as username; role is always Student
    regUserCtrl.text = email;
    role = 'Student';
    // Instead of direct registration, send OTP for verification
    _sendOtpAndShowVerification();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Logo + Brand Name
                  const Center(child: AppLogo(size: 110)),
                  const SizedBox(height: 14),
                  Center(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        Text(
                          'EDU',
                          style: TextStyle(
                            fontFamily: 'AlegreyaSC',
                            fontSize: 42,
                            fontWeight: FontWeight.w700,
                            color: Colors.grey[900],
                            letterSpacing: 1.0,
                          ),
                        ),
                        RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: 's',
                                style: TextStyle(
                                  fontFamily: 'AlexBrush',
                                  fontSize: 30,
                                  fontWeight: FontWeight.w300,
                                  color: Colors.grey[800],
                                  letterSpacing: 0.0,
                                ),
                              ),
                              TextSpan(
                                text: 'hare',
                                style: TextStyle(
                                  fontFamily: 'AlexBrush',
                                  fontSize: 40,
                                  fontWeight: FontWeight.w300,
                                  color: Colors.grey[800],
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),

                  if (isOtpVerification) ...[
                    // OTP Verification UI - matches screenshot
                    const Text(
                      'Enter verification code',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF222222),
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'To verify your identity on this device, enter the verification code sent to your gmail account.',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey[600],
                        height: 1.5,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: otpCtrl,
                      keyboardType: TextInputType.number,
                      maxLength: 6,
                      style: const TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Enter code:',
                        hintStyle: const TextStyle(color: Colors.white70, fontSize: 14),
                        counterText: '',
                        filled: true,
                        fillColor: const Color(0xFFB07070),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xFFA45C5C), width: 2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    _RoseButton(
                      label: 'Verify →',
                      onPressed: _verifyOtp,
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextButton(
                          onPressed: _resendOtp,
                          child: Text('Resend code', style: TextStyle(color: kPrimaryRose, fontSize: 13)),
                        ),
                        Text('·', style: TextStyle(color: Colors.grey[400])),
                        TextButton(
                          onPressed: _cancelOtpVerification,
                          child: Text('Cancel', style: TextStyle(color: Colors.grey[500], fontSize: 13)),
                        ),
                      ],
                    ),
                  ] else if (isPasswordReset) ...[
                    // Password Reset UI
                    const Text(
                      'Enter verification code',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF222222),
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'To verify your identity on this device, enter the verification code sent to your gmail account.',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey[600],
                        height: 1.5,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: resetOtpCtrl,
                      keyboardType: TextInputType.number,
                      maxLength: 6,
                      style: const TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Enter code:',
                        hintStyle: const TextStyle(color: Colors.white70, fontSize: 14),
                        counterText: '',
                        filled: true,
                        fillColor: const Color(0xFFB07070),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xFFA45C5C), width: 2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    _RoseButton(
                      label: 'Verify →',
                      onPressed: _verifyResetOtp,
                    ),
                    const SizedBox(height: 12),
                    Center(
                      child: TextButton(
                        onPressed: _cancelPasswordReset,
                        child: Text('Cancel', style: TextStyle(color: Colors.grey[500], fontSize: 13)),
                      ),
                    ),
                  ] else if (isLogin) ...[
                    // --- SIGN IN ---
                    _RoseField(
                      controller: loginUserCtrl,
                      hintText: 'Enter your email',
                      label: 'Email',
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 12),
                    _RoseField(
                      controller: loginPassCtrl,
                      hintText: 'Enter your password',
                      label: 'Password',
                      obscureText: true,
                    ),
                    const SizedBox(height: 20),
                    _RoseButton(
                      label: 'Sign In →',
                      onPressed: _submit,
                    ),
                    const SizedBox(height: 12),
                    Center(
                      child: GestureDetector(
                        onTap: () => setState(() => isLogin = false),
                        child: RichText(
                          text: TextSpan(
                            text: "Don't have an account? ",
                            style: TextStyle(color: Colors.grey[700], fontSize: 13),
                            children: const [
                              TextSpan(
                                text: 'Sign Up',
                                style: TextStyle(
                                  color: Color(0xFFA45C5C),
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Center(
                      child: TextButton(
                        onPressed: _showForgotPasswordDialog,
                        child: Text(
                          'Forgot Password?',
                          style: TextStyle(color: Colors.grey[500], fontSize: 13),
                        ),
                      ),
                    ),
                  ] else ...[
                    // --- SIGN UP ---
                    _RoseField(
                      controller: regNameCtrl,
                      hintText: 'Enter your full name',
                      label: 'Full Name',
                    ),
                    const SizedBox(height: 12),
                    _RoseField(
                      controller: regEmailCtrl,
                      hintText: 'Enter your email',
                      label: 'Email',
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 12),
                    _RoseField(
                      controller: regPassCtrl,
                      hintText: 'Create strong password',
                      label: 'Password',
                      obscureText: true,
                    ),
                    const SizedBox(height: 20),
                    _RoseButton(
                      label: 'Create account →',
                      onPressed: _submit,
                    ),
                    const SizedBox(height: 12),
                    Center(
                      child: GestureDetector(
                        onTap: () => setState(() => isLogin = true),
                        child: RichText(
                          text: TextSpan(
                            text: 'Already have an account? ',
                            style: TextStyle(color: Colors.grey[700], fontSize: 13),
                            children: const [
                              TextSpan(
                                text: 'Sign In',
                                style: TextStyle(
                                  color: Color(0xFFA45C5C),
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.currentUser,
    required this.messages,
    required this.lessonPlans,
    required this.todos,
    required this.events,
    required this.announcements,
    required this.libraryItems,
    required this.allLibraryItems,
    required this.onLogout,
    required this.onDeleteAccount,
    required this.onSendMessage,
    required this.onSendAttachment,
    required this.onDeleteMessage,
    required this.onCreateLessonPlan,
    required this.onUpdateLessonPlan,
    required this.onDeleteLessonPlan,
    required this.onAddTodo,
    required this.onToggleTodo,
    required this.onEditTodo,
    required this.onDeleteTodo,
    required this.onAddEvent,
    required this.onUpdateEvent,
    required this.onDeleteEvent,
    required this.onUpdateProfile,
    required this.onShareLessonToChat,
    required this.onCreateAnnouncement,
    required this.onUpdateAnnouncement,
    required this.onDeleteAnnouncement,
    required this.onAddLibraryItem,
    required this.onUpdateLibraryItem,
    required this.onToggleLibraryItemToDo,
    required this.onDeleteLibraryItem,
    required this.onShareLibraryItemToRoom,
    required this.courses,
    required this.selectedCourseId,
    required this.onCreateCourse,
    required this.onEnrollInCourse,
    required this.onSelectCourse,
    required this.getAvailableCoursesForEnrollment,
    required this.onRenameCourse,
    required this.onDeleteCourse,
    required this.onAddCustomCourse,
    required this.onAddLibraryItemToCourse,
    required this.chatRooms,
    required this.availableStudents,
    required this.onCreateGroupChat,
    required this.onCreateDirectMessage,
    required this.onSendMessageToRoom,
    required this.onAddParticipantToGroup,
    required this.onSendAttachmentToRoom,
    required this.noteTransactions,
    required this.onShareLessonFromChat,
  });

  final EduUser currentUser;
  final List<ChatMessage> messages;
  final List<LessonPlan> lessonPlans;
  final List<TodoItem> todos;
  final List<CalendarEvent> events;
  final List<Announcement> announcements;
  final List<LibraryItem> libraryItems;
  final List<LibraryItem> allLibraryItems;
  final VoidCallback onLogout;
  final VoidCallback onDeleteAccount;
  final void Function(String text) onSendMessage;
  final void Function({
    required String caption,
    required ChatAttachmentKind kind,
    required String path,
    required String name,
    Uint8List? bytes,
  })
  onSendAttachment;
  final void Function(int index) onDeleteMessage;
  final void Function(String title, String description, DateTime date)
  onCreateLessonPlan;
  final void Function(
    int index,
    String title,
    String description,
    DateTime date,
  )
  onUpdateLessonPlan;
  final void Function(int index) onDeleteLessonPlan;
  final void Function(String title) onAddTodo;
  final void Function(int index) onToggleTodo;
  final void Function(int index, String title) onEditTodo;
  final void Function(int index) onDeleteTodo;
  final void Function(String title, String description, DateTime date)
  onAddEvent;
  final void Function(
    int index,
    String title,
    String description,
    DateTime date,
  )
  onUpdateEvent;
  final void Function(int index) onDeleteEvent;
  final void Function({
    required String fullName,
    required String email,
    required String bio,
    Uint8List? avatarBytes,
    String? gender,
    String? birthday,
    String? address,
  })
  onUpdateProfile;
  final void Function(LessonPlan lesson) onShareLessonToChat;
  final void Function(String title, String content, {bool? isPinned}) onCreateAnnouncement;
  final void Function(int index, String title, String content, {bool? isPinned}) onUpdateAnnouncement;
  final void Function(int index) onDeleteAnnouncement;
  final void Function(String title, String content) onAddLibraryItem;
  final void Function(int index, {String? title, String? content, int? color, String? fontFamily, int? backgroundColor}) onUpdateLibraryItem;
  final void Function(int index) onToggleLibraryItemToDo;
  final void Function(int index) onDeleteLibraryItem;
  final void Function(LibraryItem item, String roomId) onShareLibraryItemToRoom;
  final List<Course> courses;
  final String? selectedCourseId;
  final void Function(String name, String description) onCreateCourse;
  final void Function(String courseId) onEnrollInCourse;
  final void Function(String? courseId) onSelectCourse;
  final List<Course> Function() getAvailableCoursesForEnrollment;
  final void Function(String courseId, String newName) onRenameCourse;
  final void Function(String courseId) onDeleteCourse;
  final void Function(String name) onAddCustomCourse;
  final void Function(String title, String content, String courseId) onAddLibraryItemToCourse;
  final List<ChatRoom> chatRooms;
  final List<EduUser> availableStudents;
  final void Function(String name, String courseId) onCreateGroupChat;
  final void Function(String username, String courseId) onCreateDirectMessage;
  final void Function(String text, String roomId) onSendMessageToRoom;
  final void Function(String roomId, String username) onAddParticipantToGroup;
  final void Function({
    required String caption,
    required ChatAttachmentKind kind,
    required String path,
    required String name,
    Uint8List? bytes,
    required String roomId,
  }) onSendAttachmentToRoom;
  final List<NoteTransaction> noteTransactions;
  final void Function(LibraryItem item, String roomId, String recipientName) onShareLessonFromChat;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Nav indices: 0=Library(home), 1=Calendar, 2=Chat, 3=Transactions, 4=Settings
  int index = 0;

  void _showLogoMenu(BuildContext context) async {
    final RenderBox button = context.findRenderObject() as RenderBox;
    final RenderBox overlay = Navigator.of(context).overlay!.context.findRenderObject() as RenderBox;
    final RelativeRect position = RelativeRect.fromRect(
      Rect.fromPoints(
        button.localToGlobal(button.size.bottomLeft(Offset.zero), ancestor: overlay),
        button.localToGlobal(button.size.bottomRight(Offset.zero), ancestor: overlay),
      ),
      Offset.zero & overlay.size,
    );
    final result = await showMenu<String>(
      context: context,
      position: position,
      items: [
        const PopupMenuItem<String>(
          value: 'profile',
          child: Text('Profile'),
        ),
      ],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    );
    if (result == 'profile') {
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(
            title: const Text('Profile', style: TextStyle(color: Colors.white)),
            backgroundColor: const Color(0xFFA45C5C),
            iconTheme: const IconThemeData(color: Colors.white),
          ),
          body: ProfileTab(
            user: widget.currentUser,
            onLogout: widget.onLogout,
            onSave: widget.onUpdateProfile,
          ),
        ),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    // Fixed 5-tab navigation: Library, Calendar, Chat, Transactions, Settings
    final pages = [
      // 0 - Library home (course grid)
      CourseLibraryHome(
        user: widget.currentUser,
        courses: widget.courses,
        selectedCourseId: widget.selectedCourseId,
        onSelectCourse: widget.onSelectCourse,
        onCreateCourse: widget.onCreateCourse,
        onEnrollInCourse: widget.onEnrollInCourse,
        getAvailableCoursesForEnrollment: widget.getAvailableCoursesForEnrollment,
        libraryItems: widget.libraryItems,
        onAddLibraryItem: widget.onAddLibraryItem,
        onUpdateLibraryItem: widget.onUpdateLibraryItem,
        onToggleLibraryItemToDo: widget.onToggleLibraryItemToDo,
        onDeleteLibraryItem: widget.onDeleteLibraryItem,
        chatRooms: widget.chatRooms,
        onShareLibraryItemToRoom: widget.onShareLibraryItemToRoom,
        onRenameCourse: widget.onRenameCourse,
        onDeleteCourse: widget.onDeleteCourse,
        onAddCustomCourse: widget.onAddCustomCourse,
        onAddLibraryItemToCourse: widget.onAddLibraryItemToCourse,
      ),
      // 1 - Calendar
      CalendarTab(
        user: widget.currentUser,
        events: widget.events,
        onAddEvent: widget.onAddEvent,
        onUpdateEvent: widget.onUpdateEvent,
        onDeleteEvent: widget.onDeleteEvent,
      ),
      // 2 - Chat
      ChatTab(
        currentUser: widget.currentUser,
        messages: widget.messages,
        chatRooms: widget.chatRooms,
        availableStudents: widget.availableStudents,
        selectedCourseId: widget.selectedCourseId,
        onSendMessage: widget.onSendMessage,
        onSendAttachment: widget.onSendAttachment,
        onDeleteMessage: widget.onDeleteMessage,
        onCreateGroupChat: widget.onCreateGroupChat,
        onCreateDirectMessage: widget.onCreateDirectMessage,
        onSendMessageToRoom: widget.onSendMessageToRoom,
        onAddParticipantToGroup: widget.onAddParticipantToGroup,
        onSendAttachmentToRoom: widget.onSendAttachmentToRoom,
        libraryItems: widget.allLibraryItems,
        onShareLessonFromChat: widget.onShareLessonFromChat,
        courses: widget.courses,
      ),
      // 3 - Transactions
      TransactionsTab(
        currentUser: widget.currentUser,
        noteTransactions: widget.noteTransactions,
      ),
      // 4 - Settings
      SettingsTab(
        user: widget.currentUser,
        onLogout: widget.onLogout,
        onDeleteAccount: widget.onDeleteAccount,
      ),
    ];

    // Fixed 5-destination bottom nav
    const destinations = [
      NavigationDestination(
        icon: Icon(Icons.auto_stories_outlined),
        selectedIcon: Icon(Icons.auto_stories),
        label: 'Library',
      ),
      NavigationDestination(
        icon: Icon(Icons.calendar_month_outlined),
        selectedIcon: Icon(Icons.calendar_month),
        label: 'Calendar',
      ),
      NavigationDestination(
        icon: Icon(Icons.forum_outlined),
        selectedIcon: Icon(Icons.forum),
        label: 'Chat',
      ),
      NavigationDestination(
        icon: Icon(Icons.receipt_long_outlined),
        selectedIcon: Icon(Icons.receipt_long),
        label: 'Transactions',
      ),
      NavigationDestination(
        icon: Icon(Icons.settings_outlined),
        selectedIcon: Icon(Icons.settings),
        label: 'Settings',
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        leading: Builder(
          builder: (ctx) => GestureDetector(
            onTap: () => _showLogoMenu(ctx),
            child: const AppLogo(size: 80),
          ),
        ),
        title: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Edu',
                    style: TextStyle(
                      fontFamily: 'AlegreyaSC',
                      fontSize: 32,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      letterSpacing: -0.5,
                    ),
                  ),
                  Text(
                    'Share',
                    style: TextStyle(
                      fontFamily: 'AlexBrush',
                      fontSize: 30,
                      fontWeight: FontWeight.w300,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: widget.onLogout,
          ),
        ],
      ),
      body: IndexedStack(
        index: index,
        children: pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: destinations,
      ),
    );
  }

}

// ─────────────────────────────────────────────────────────────────────────────
// CourseLibraryHome – the new "Library" home tab showing course folders in a grid
// ─────────────────────────────────────────────────────────────────────────────
class CourseLibraryHome extends StatefulWidget {
  const CourseLibraryHome({
    super.key,
    required this.user,
    required this.courses,
    required this.selectedCourseId,
    required this.onSelectCourse,
    required this.onCreateCourse,
    required this.onEnrollInCourse,
    required this.getAvailableCoursesForEnrollment,
    required this.libraryItems,
    required this.onAddLibraryItem,
    required this.onUpdateLibraryItem,
    required this.onToggleLibraryItemToDo,
    required this.onDeleteLibraryItem,
    required this.chatRooms,
    required this.onShareLibraryItemToRoom,
    required this.onRenameCourse,
    required this.onDeleteCourse,
    required this.onAddCustomCourse,
    required this.onAddLibraryItemToCourse,
  });

  final EduUser user;
  final List<Course> courses;
  final String? selectedCourseId;
  final void Function(String? courseId) onSelectCourse;
  final void Function(String name, String description) onCreateCourse;
  final void Function(String courseId) onEnrollInCourse;
  final List<Course> Function() getAvailableCoursesForEnrollment;
  final List<LibraryItem> libraryItems;
  final void Function(String title, String content) onAddLibraryItem;
  final void Function(int index, {String? title, String? content, int? color, String? fontFamily, int? backgroundColor}) onUpdateLibraryItem;
  final void Function(int index) onToggleLibraryItemToDo;
  final void Function(int index) onDeleteLibraryItem;
  final List<ChatRoom> chatRooms;
  final void Function(LibraryItem item, String roomId) onShareLibraryItemToRoom;
  final void Function(String courseId, String newName) onRenameCourse;
  final void Function(String courseId) onDeleteCourse;
  final void Function(String name) onAddCustomCourse;
  final void Function(String title, String content, String courseId) onAddLibraryItemToCourse;

  @override
  State<CourseLibraryHome> createState() => _CourseLibraryHomeState();
}

class _CourseLibraryHomeState extends State<CourseLibraryHome> {
  Course? _openedCourse;

  // Persistent per-course customisation (keyed by course.id)
  final Map<String, Color> _courseColors = {};
  final Map<String, Color> _courseBgColors = {};
  final Map<String, String> _courseFonts = {};
  final Map<String, List<String>> _courseTodos = {};

  // Colors cycling for course folders to match the rose-mauve palette
  static const List<Color> _folderColors = [
    Color(0xFFA45C5C),
    Color(0xFF9B6B6B),
    Color(0xFF8B7070),
    Color(0xFF7A6060),
    Color(0xFFB07080),
    Color(0xFF956060),
  ];

  Color _courseColor(int index) => _folderColors[index % _folderColors.length];

  @override
  Widget build(BuildContext context) {
    if (_openedCourse != null) {
      return _buildCourseLibrary();
    }
    return _buildCourseGrid();
  }

  Widget _buildCourseGrid() {
    final courses = widget.courses;

    return Scaffold(
      backgroundColor: Colors.white,
      floatingActionButton: widget.user.role == 'Teacher'
          ? FloatingActionButton(
              onPressed: _showCreateCourseDialog,
              backgroundColor: Colors.white,
              foregroundColor: kPrimaryRose,
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: const BorderSide(color: kPrimaryRose, width: 1.5),
              ),
              child: const Icon(Icons.add_box_outlined, size: 28),
            )
          : FloatingActionButton(
              onPressed: _showEnrollDialog,
              backgroundColor: Colors.white,
              foregroundColor: kPrimaryRose,
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: const BorderSide(color: kPrimaryRose, width: 1.5),
              ),
              child: const Icon(Icons.add_box_outlined, size: 28),
            ),
      body: courses.isEmpty
          ? _buildEmptyState()
          : Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: GridView.builder(
                itemCount: courses.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                  childAspectRatio: 1.0,
                ),
                itemBuilder: (context, i) {
                  final course = courses[i];
                  final color = _courseColor(i);
                  return _CourseFolderTile(
                    key: ValueKey(course.id),
                    course: course,
                    color: color,
                    isSelected: widget.selectedCourseId == course.id,
                    initialOverrideColor: _courseColors[course.id],
                    initialOverrideBg: _courseBgColors[course.id],
                    initialFont: _courseFonts[course.id] ?? '',
                    initialTodos: _courseTodos[course.id] ?? [],
                    onTap: () {
                      widget.onSelectCourse(course.id);
                      setState(() => _openedCourse = course);
                    },
                    onRename: (newName) {
                      widget.onRenameCourse(course.id, newName);
                      if (_openedCourse?.id == course.id) {
                        setState(() => _openedCourse = course.copyWith(name: newName));
                      }
                    },
                    onRemove: () {
                      widget.onDeleteCourse(course.id);
                      _courseColors.remove(course.id);
                      _courseBgColors.remove(course.id);
                      _courseFonts.remove(course.id);
                      _courseTodos.remove(course.id);
                      if (_openedCourse?.id == course.id) {
                        setState(() => _openedCourse = null);
                      }
                    },
                    onColorChanged: (c) => setState(() => _courseColors[course.id] = c),
                    onBgColorChanged: (c) => setState(() => _courseBgColors[course.id] = c),
                    onFontChanged: (f) => setState(() => _courseFonts[course.id] = f),
                    onTodosChanged: (t) => setState(() => _courseTodos[course.id] = t),
                  );
                },
              ),
            ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: kPrimaryRose.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.auto_stories_outlined, size: 40, color: kPrimaryRose),
            ),
            const SizedBox(height: 24),
            Text(
              widget.user.role == 'Teacher' ? 'No courses yet' : 'Not enrolled yet',
              style: const TextStyle(
                fontFamily: 'AlegreyaSC',
                fontSize: 20,
                color: Color(0xFF5A3A3A),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              widget.user.role == 'Teacher'
                  ? 'Tap the + button to create your first course.'
                  : 'Tap the enroll button to join a course.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Colors.grey[500]),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: widget.user.role == 'Teacher' ? _showCreateCourseDialog : _showEnrollDialog,
              icon: Icon(widget.user.role == 'Teacher' ? Icons.add : Icons.school),
              label: Text(widget.user.role == 'Teacher' ? 'Create Course' : 'Enroll'),
              style: FilledButton.styleFrom(backgroundColor: kPrimaryRose),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCourseLibrary() {
    final courseItems = widget.libraryItems
        .where((item) => item.courseId == _openedCourse!.id)
        .toList();
    return _CourseNotesScreen(
      course: _openedCourse!,
      libraryItems: courseItems,
      onBack: () => setState(() => _openedCourse = null),
      onAddLibraryItem: (title, content) =>
          widget.onAddLibraryItemToCourse(title, content, _openedCourse!.id),
      onDeleteLibraryItem: (index) {
        // Find global index from courseItems[index]
        if (index < courseItems.length) {
          final item = courseItems[index];
          final globalIndex = widget.libraryItems.indexWhere((i) => i.id == item.id);
          if (globalIndex != -1) widget.onDeleteLibraryItem(globalIndex);
        }
      },
    );
  }

  void _showCreateCourseDialog() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        final nameCtrl = TextEditingController();
        final descCtrl = TextEditingController();
        return AlertDialog(
          title: const Text('Create Course'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(labelText: 'Course Name'),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: descCtrl,
                decoration: const InputDecoration(labelText: 'Description'),
                maxLines: 3,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                nameCtrl.dispose();
                descCtrl.dispose();
                Navigator.pop(dialogContext);
              },
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                if (nameCtrl.text.trim().isNotEmpty && descCtrl.text.trim().isNotEmpty) {
                  widget.onCreateCourse(nameCtrl.text.trim(), descCtrl.text.trim());
                  nameCtrl.dispose();
                  descCtrl.dispose();
                  Navigator.pop(dialogContext);
                }
              },
              child: const Text('Create'),
            ),
          ],
        );
      },
    );
  }

  void _showEnrollDialog() {
    final availableCourses = widget.getAvailableCoursesForEnrollment();
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFFFFF5F5),
        title: Text('Enroll in Course (${availableCourses.length} available)'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (availableCourses.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(8),
                  child: Text('No courses available for enrollment.'),
                )
              else
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 360),
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: availableCourses.length,
                    itemBuilder: (context, index) {
                      final course = availableCourses[index];
                      return Card(
                        child: ListTile(
                          title: Text(course.name),
                          subtitle: Text(course.description),
                          trailing: const Icon(Icons.add_circle_outline),
                          onTap: () {
                            widget.onEnrollInCourse(course.id);
                            Navigator.pop(dialogContext);
                          },
                        ),
                      );
                    },
                  ),
                ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.add_box_outlined, color: Color(0xFFA45C5C)),
                title: const Text('Add custom course'),
                subtitle: const Text('Create your own course'),
                onTap: () {
                  Navigator.pop(dialogContext);
                  _showAddCustomCourseDialog();
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _showAddCustomCourseDialog() {
    final nameCtrl = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add Custom Course'),
        content: TextField(
          controller: nameCtrl,
          decoration: const InputDecoration(
            labelText: 'Course name',
            hintText: 'e.g. MATH101',
          ),
          textCapitalization: TextCapitalization.characters,
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFA45C5C)),
            onPressed: () {
              final name = nameCtrl.text.trim();
              if (name.isNotEmpty) {
                widget.onAddCustomCourse(name);
                Navigator.pop(ctx);
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }
}

// Single course folder tile for the grid
class _CourseFolderTile extends StatefulWidget {
  const _CourseFolderTile({
    super.key,
    required this.course,
    required this.color,
    required this.isSelected,
    required this.onTap,
    this.onRename,
    this.onRemove,
    this.initialOverrideColor,
    this.initialOverrideBg,
    this.initialFont = '',
    this.initialTodos = const [],
    this.onColorChanged,
    this.onBgColorChanged,
    this.onFontChanged,
    this.onTodosChanged,
  });

  final Course course;
  final Color color;
  final bool isSelected;
  final VoidCallback onTap;
  final void Function(String newName)? onRename;
  final VoidCallback? onRemove;
  final Color? initialOverrideColor;
  final Color? initialOverrideBg;
  final String initialFont;
  final List<String> initialTodos;
  final void Function(Color)? onColorChanged;
  final void Function(Color)? onBgColorChanged;
  final void Function(String)? onFontChanged;
  final void Function(List<String>)? onTodosChanged;

  @override
  State<_CourseFolderTile> createState() => _CourseFolderTileState();
}

class _CourseFolderTileState extends State<_CourseFolderTile> {
  Color? _overrideColor;
  Color? _overrideBg;
  String _fontFamily = '';
  late List<String> _todos;

  @override
  void initState() {
    super.initState();
    _overrideColor = widget.initialOverrideColor;
    _overrideBg = widget.initialOverrideBg;
    _fontFamily = widget.initialFont;
    _todos = List<String>.from(widget.initialTodos);
  }

  Color get _effectiveColor => _overrideColor ?? widget.color;

  void _showFolderMenu(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFFFFF5F5),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: _effectiveColor,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Row(
              children: [
                const Icon(Icons.folder, color: Colors.white, size: 28),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    widget.course.name,
                    style: const TextStyle(
                      color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.share_outlined),
            title: const Text('Share'),
            onTap: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Sharing "${widget.course.name}"...')),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.edit_outlined),
            title: const Text('Rename'),
            onTap: () { Navigator.pop(ctx); _showRenameDialog(context); },
          ),
          ListTile(
            leading: const Icon(Icons.palette_outlined),
            title: const Text('Change color'),
            onTap: () { Navigator.pop(ctx); _showColorPicker(context); },
          ),
          ListTile(
            leading: const Icon(Icons.text_fields),
            title: const Text('Font'),
            onTap: () { Navigator.pop(ctx); _showFontPicker(context); },
          ),
          ListTile(
            leading: const Icon(Icons.image_outlined),
            title: const Text('Background'),
            onTap: () { Navigator.pop(ctx); _showBgColorPicker(context); },
          ),
          ListTile(
            leading: const Icon(Icons.checklist_outlined),
            title: const Text('To Do'),
            onTap: () { Navigator.pop(ctx); _showToDoList(context); },
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline, color: Colors.red),
            title: const Text('Remove', style: TextStyle(color: Colors.red)),
            onTap: () { Navigator.pop(ctx); widget.onRemove?.call(); },
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  void _showRenameDialog(BuildContext context) {
    final ctrl = TextEditingController(text: widget.course.name);
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename'),
        content: TextField(
          controller: ctrl,
          decoration: const InputDecoration(labelText: 'New name'),
          autofocus: true,
          textCapitalization: TextCapitalization.characters,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFA45C5C)),
            onPressed: () {
              final name = ctrl.text.trim();
              if (name.isNotEmpty) widget.onRename?.call(name);
              Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showColorPicker(BuildContext context) {
    const colors = [
      Color(0xFFA45C5C), Color(0xFF7B6FA0), Color(0xFF4A7C6F), Color(0xFF5C7A9E),
      Color(0xFFB07040), Color(0xFF6B8E6B), Color(0xFF9E5C7A), Color(0xFF5C6E8E),
      Color(0xFF8E7A5C), Color(0xFF5C8E8E), Color(0xFF8E5C5C), Color(0xFF5C7A5C),
    ];
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Change color'),
        content: SizedBox(
          width: double.maxFinite,
          child: GridView.count(
            crossAxisCount: 4, shrinkWrap: true,
            mainAxisSpacing: 10, crossAxisSpacing: 10,
            children: colors.map((c) {
              final isSel = c.value == _effectiveColor.value;
              return GestureDetector(
                onTap: () { setState(() => _overrideColor = c); widget.onColorChanged?.call(c); Navigator.pop(ctx); },
                child: Container(
                  decoration: BoxDecoration(
                    color: c, borderRadius: BorderRadius.circular(10),
                    border: isSel ? Border.all(color: Colors.white, width: 3) : null,
                    boxShadow: isSel ? [BoxShadow(color: c.withValues(alpha: 0.5), blurRadius: 6)] : null,
                  ),
                  child: isSel ? const Icon(Icons.check, color: Colors.white, size: 20) : null,
                ),
              );
            }).toList(),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel'))],
      ),
    );
  }

  void _showBgColorPicker(BuildContext context) {
    final bgColors = <Map<String,dynamic>>[
      {'value': const Color(0xFFFFFAF0), 'label': 'Floral White'},
      {'value': const Color(0xFFFFF5EE), 'label': 'Seashell'},
      {'value': const Color(0xFFFFF8DC), 'label': 'Cornsilk'},
      {'value': const Color(0xFFFFFFF0), 'label': 'Ivory'},
      {'value': const Color(0xFFE8F5E9), 'label': 'Mint'},
      {'value': const Color(0xFFE3F2FD), 'label': 'Sky Blue'},
      {'value': const Color(0xFFFCE4EC), 'label': 'Blush'},
      {'value': const Color(0xFFF3E5F5), 'label': 'Lavender'},
      {'value': const Color(0xFFFFF9C4), 'label': 'Lemon'},
      {'value': const Color(0xFFFFE0B2), 'label': 'Peach'},
      {'value': const Color(0xFFE0F7FA), 'label': 'Aqua'},
      {'value': const Color(0xFFEFEBE9), 'label': 'Warm Gray'},
      {'value': Colors.white, 'label': 'White'},
      {'value': const Color(0xFFF5F5F5), 'label': 'Light Gray'},
    ];
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Background'),
        content: SizedBox(
          width: double.maxFinite,
          child: GridView.count(
            crossAxisCount: 4, shrinkWrap: true,
            mainAxisSpacing: 8, crossAxisSpacing: 8,
            children: bgColors.map((e) {
              final c = e['value'] as Color;
              final isSel = _overrideBg?.value == c.value;
              return GestureDetector(
                onTap: () { setState(() => _overrideBg = c); widget.onBgColorChanged?.call(c); Navigator.pop(ctx); },
                child: Tooltip(
                  message: e['label'] as String,
                  child: Container(
                    decoration: BoxDecoration(
                      color: c, borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isSel ? const Color(0xFFA45C5C) : Colors.grey.shade300,
                        width: isSel ? 2.5 : 1,
                      ),
                    ),
                    child: isSel ? const Icon(Icons.check, size: 16, color: Colors.black54) : null,
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel'))],
      ),
    );
  }

  void _showFontPicker(BuildContext context) {
    final fonts = [('Default', ''), ('AlegreyaSC', 'AlegreyaSC'), ('AlexBrush', 'AlexBrush')];
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Choose Font'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: fonts.map((pair) {
            final label = pair.$1; final value = pair.$2;
            final isSel = _fontFamily == value;
            return ListTile(
              leading: Icon(isSel ? Icons.radio_button_checked : Icons.radio_button_off,
                  color: isSel ? const Color(0xFFA45C5C) : Colors.grey),
              title: Text(label, style: TextStyle(fontFamily: value.isEmpty ? null : value, fontSize: 16)),
              onTap: () { setState(() => _fontFamily = value); widget.onFontChanged?.call(value); Navigator.pop(ctx); },
            );
          }).toList(),
        ),
      ),
    );
  }

  void _showToDoList(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => _ToDoListPage(
        courseName: widget.course.name,
        initialItems: List<String>.from(_todos),
        onSave: (items) {
          setState(() { _todos.clear(); _todos.addAll(items); });
          widget.onTodosChanged?.call(items);
        },
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          color: _overrideBg ?? _effectiveColor,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: _effectiveColor.withValues(alpha: widget.isSelected ? 0.55 : 0.28),
              blurRadius: widget.isSelected ? 14 : 6,
              offset: const Offset(0, 4),
            ),
          ],
          border: widget.isSelected ? Border.all(color: Colors.white, width: 2.5) : null,
        ),
        child: Stack(
          children: [
            // Three-dot menu button
            Positioned(
              top: 2, right: 2,
              child: GestureDetector(
                onTap: () => _showFolderMenu(context),
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(Icons.more_vert,
                    color: (_overrideBg != null ? Colors.black54 : Colors.white).withValues(alpha: 0.85),
                    size: 20),
                ),
              ),
            ),
            // Course name
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text(
                  widget.course.name.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: _fontFamily.isEmpty ? null : _fontFamily,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: _overrideBg != null ? Colors.black87 : Colors.white,
                    letterSpacing: 0.5, height: 1.25,
                  ),
                  maxLines: 3, overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────── To Do List Bottom Sheet ────────────────────────────
class _ToDoListPage extends StatefulWidget {
  const _ToDoListPage({
    required this.courseName,
    required this.initialItems,
    required this.onSave,
  });
  final String courseName;
  final List<String> initialItems;
  final void Function(List<String> items) onSave;

  @override
  State<_ToDoListPage> createState() => _ToDoListPageState();
}

class _ToDoListPageState extends State<_ToDoListPage> {
  late final List<String> _items;
  final _ctrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _items = List<String>.from(widget.initialItems);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _addItem() {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    setState(() { _items.add(text); _ctrl.clear(); });
    widget.onSave(_items);
  }

  void _removeItem(int index) {
    setState(() => _items.removeAt(index));
    widget.onSave(_items);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black87, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Row(
          children: [
            Icon(Icons.edit_note_outlined, color: Colors.black87, size: 22),
            SizedBox(width: 8),
            Text(
              'TO DO LIST',
              style: TextStyle(
                color: Colors.black87,
                fontSize: 16,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
      body: _items.isEmpty
          ? const SizedBox.shrink()
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
              itemCount: _items.length,
              itemBuilder: (_, i) => Dismissible(
                key: ValueKey('todo-$i-${_items[i]}'),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 16),
                  color: Colors.red.shade100,
                  child: const Icon(Icons.delete_outline, color: Colors.red),
                ),
                onDismissed: (_) => _removeItem(i),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5EDED),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          _items[i],
                          style: const TextStyle(
                            fontSize: 15,
                            color: Color(0xFF5A3A3A),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () => _removeItem(i),
                        child: const Icon(Icons.close, color: Color(0xFFA45C5C), size: 18),
                      ),
                    ],
                  ),
                ),
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddDialog(context),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Colors.black26),
        ),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showAddDialog(BuildContext context) {
    _ctrl.clear();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add To Do Item'),
        content: TextField(
          controller: _ctrl,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Enter task...'),
          textCapitalization: TextCapitalization.sentences,
          onSubmitted: (_) { _addItem(); Navigator.pop(ctx); },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: kPrimaryRose),
            onPressed: () { _addItem(); Navigator.pop(ctx); },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }
}
// ─────────────────────────────────────────────────────────────────────────────
// _CourseNotesScreen — lesson list + content viewer matching the screenshot UI
// ─────────────────────────────────────────────────────────────────────────────
class _CourseNotesScreen extends StatefulWidget {
  const _CourseNotesScreen({
    required this.course,
    required this.libraryItems,
    required this.onBack,
    required this.onAddLibraryItem,
    required this.onDeleteLibraryItem,
  });

  final Course course;
  final List<LibraryItem> libraryItems;
  final VoidCallback onBack;
  final void Function(String title, String content) onAddLibraryItem;
  final void Function(int index) onDeleteLibraryItem;

  @override
  State<_CourseNotesScreen> createState() => _CourseNotesScreenState();
}

class _CourseNotesScreenState extends State<_CourseNotesScreen> {
  LibraryItem? _selectedItem;

  @override
  void initState() {
    super.initState();
    // Auto-select first item if available
    if (widget.libraryItems.isNotEmpty) {
      _selectedItem = null; // start on list view
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_selectedItem != null) {
      return _buildContentView();
    }
    return _buildLessonList();
  }

  Widget _buildLessonList() {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Course name header — rose pill banner
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: kPrimaryRose,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  widget.course.name.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ),

            // Lesson list
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: widget.libraryItems.length,
                itemBuilder: (context, index) {
                  final item = widget.libraryItems[index];
                  final isSystem = item.createdBy == 'system';
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFFC07070),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(8),
                        onTap: () => setState(() => _selectedItem = item),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  item.title,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              if (!isSystem)
                                GestureDetector(
                                  onTap: () {
                                    widget.onDeleteLibraryItem(index);
                                    if (_selectedItem?.id == item.id) {
                                      setState(() => _selectedItem = null);
                                    }
                                  },
                                  child: const Icon(
                                    Icons.delete_outline,
                                    color: Colors.white70,
                                    size: 20,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            // Bottom action bar — back + add
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 8, 28, 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Back arrow
                  GestureDetector(
                    onTap: widget.onBack,
                    child: const Icon(Icons.reply, size: 30, color: Colors.black54),
                  ),
                  // Add note button
                  GestureDetector(
                    onTap: _showAddNoteDialog,
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black54, width: 1.5),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.add, color: Colors.black54, size: 22),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContentView() {
    final item = _selectedItem!;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Course name header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: kPrimaryRose,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  widget.course.name.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ),

            // Lesson title
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                item.title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: 'AlexBrush',
                  fontSize: 28,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  item.content,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black87,
                    height: 1.6,
                  ),
                ),
              ),
            ),

            // Bottom bar — back only (no add button on content view)
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 8, 28, 20),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => setState(() => _selectedItem = null),
                    child: const Icon(Icons.reply, size: 30, color: Colors.black54),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddNoteDialog() {
    final titleCtrl = TextEditingController();
    final contentCtrl = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFFFFF5F5),
        title: const Text('Add Note'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: titleCtrl,
                decoration: const InputDecoration(
                  labelText: 'Title (e.g. Lesson 2)',
                  border: UnderlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              const Text('Content', style: TextStyle(fontSize: 12, color: Colors.black54)),
              const SizedBox(height: 4),
              TextField(
                controller: contentCtrl,
                decoration: const InputDecoration(
                  border: UnderlineInputBorder(),
                ),
                maxLines: 7,
                minLines: 4,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFA45C5C)),
            onPressed: () {
              final title = titleCtrl.text.trim();
              final contentText = contentCtrl.text.trim();
              if (title.isNotEmpty && contentText.isNotEmpty) {
                widget.onAddLibraryItem(title, contentText);
                Navigator.pop(ctx);
              } else {
                ScaffoldMessenger.of(ctx).showSnackBar(
                  const SnackBar(content: Text('Please fill in both title and content.')),
                );
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }
}

class DashboardTab extends StatefulWidget {
  const DashboardTab({
    super.key,
    required this.user,
    required this.todos,
    required this.lessonPlans,
    required this.onAddTodo,
    required this.onToggleTodo,
    required this.onEditTodo,
    required this.onDeleteTodo,
  });

  final EduUser user;
  final List<TodoItem> todos;
  final List<LessonPlan> lessonPlans;
  final void Function(String title) onAddTodo;
  final void Function(int index) onToggleTodo;
  final void Function(int index, String title) onEditTodo;
  final void Function(int index) onDeleteTodo;

  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  late final TextEditingController _todoCtrl;

  @override
  void initState() {
    super.initState();
    _todoCtrl = TextEditingController();
  }

  @override
  void dispose() {
    _todoCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final doneCount = widget.todos.where((t) => t.isDone).length;
    final ratio = widget.todos.isEmpty ? 0.0 : doneCount / widget.todos.length;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            leading: UserAvatar(user: widget.user, radius: 22),
            title: Text('Welcome, ${widget.user.fullName}'),
            subtitle: Text('Role: ${widget.user.role}'),
          ),
        ),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                CircularPercentIndicator(
                  radius: 44,
                  lineWidth: 9,
                  percent: ratio.clamp(0.0, 1.0),
                  progressColor: kPrimaryRose,
                  backgroundColor: const Color.fromRGBO(164, 92, 92, 0.15),
                  center: Text('${(ratio * 100).round()}%'),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    'Progress: $doneCount/${widget.todos.length} tasks completed',
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Todo List',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _todoCtrl,
                        decoration: const InputDecoration(
                          hintText: 'Add a task',
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    FilledButton(
                      onPressed: () {
                        widget.onAddTodo(_todoCtrl.text);
                        _todoCtrl.clear();
                      },
                      child: const Text('Add'),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ...List.generate(widget.todos.length, (i) {
                  return Dismissible(
                    key: ValueKey('todo-$i'),
                    direction: DismissDirection.endToStart,
                    onDismissed: (_) => widget.onDeleteTodo(i),
                    background: Container(
                      color: Colors.red.shade300,
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 12),
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    child: ListTile(
                      leading: Checkbox(
                        value: widget.todos[i].isDone,
                        onChanged: (_) => widget.onToggleTodo(i),
                      ),
                      title: Text(widget.todos[i].title),
                      trailing: IconButton(
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () =>
                            _showEditTodoDialog(i, widget.todos[i].title),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _showEditTodoDialog(int index, String title) async {
    final ctrl = TextEditingController(text: title);
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Edit Todo'),
        content: TextField(controller: ctrl),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              widget.onEditTodo(index, ctrl.text);
              Navigator.pop(dialogContext);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    ctrl.dispose();
  }
}

class ChatTab extends StatefulWidget {
  const ChatTab({
    super.key,
    required this.currentUser,
    required this.messages,
    required this.chatRooms,
    required this.availableStudents,
    required this.selectedCourseId,
    required this.onSendMessage,
    required this.onSendAttachment,
    required this.onDeleteMessage,
    required this.onCreateGroupChat,
    required this.onCreateDirectMessage,
    required this.onSendMessageToRoom,
    required this.onAddParticipantToGroup,
    required this.onSendAttachmentToRoom,
    required this.libraryItems,
    required this.courses,
    required this.onShareLessonFromChat,
  });

  final EduUser currentUser;
  final List<ChatMessage> messages;
  final List<ChatRoom> chatRooms;
  final List<EduUser> availableStudents;
  final String? selectedCourseId;
  final List<LibraryItem> libraryItems;
  final List<Course> courses;
  final void Function(String text) onSendMessage;
  final void Function({
    required String caption,
    required ChatAttachmentKind kind,
    required String path,
    required String name,
    Uint8List? bytes,
  })
  onSendAttachment;
  final void Function(int index) onDeleteMessage;
  final void Function(String name, String courseId) onCreateGroupChat;
  final void Function(String username, String courseId) onCreateDirectMessage;
  final void Function(String text, String roomId) onSendMessageToRoom;
  final void Function(String roomId, String username) onAddParticipantToGroup;
  final void Function({
    required String caption,
    required ChatAttachmentKind kind,
    required String path,
    required String name,
    Uint8List? bytes,
    required String roomId,
  })
  onSendAttachmentToRoom;
  final void Function(LibraryItem item, String roomId, String recipientName) onShareLessonFromChat;

  @override
  State<ChatTab> createState() => _ChatTabState();
}

class _ChatTabState extends State<ChatTab> {
  late final TextEditingController _ctrl;
  late final ScrollController _scrollCtrl;
  final _imagePicker = ImagePicker();
  ChatRoom? _selectedRoom;

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController();
    _scrollCtrl = ScrollController();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _showChatRoom(ChatRoom room) {
    setState(() {
      _selectedRoom = room;
    });
    _scrollToBottom();
  }

  void _deleteRoomMessage(ChatMessage message) {
    // Find the actual message index in the main messages list
    final actualIndex = widget.messages.indexOf(message);
    if (actualIndex != -1) {
      widget.onDeleteMessage(actualIndex);
    }
  }

  void _showCreateGroupDialog() {
    final nameCtrl = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Create Group Chat'),
        content: TextField(
          controller: nameCtrl,
          decoration: const InputDecoration(labelText: 'Group Name'),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (nameCtrl.text.trim().isNotEmpty) {
                widget.onCreateGroupChat(nameCtrl.text.trim(), widget.selectedCourseId ?? 'default');
                Navigator.pop(dialogContext);
              }
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  void _showDMStudentDialog() {
    if (widget.availableStudents.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No other students available to message')),
      );
      return;
    }

    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Start Direct Message'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: widget.availableStudents.length,
            itemBuilder: (context, index) {
              final student = widget.availableStudents[index];
              return ListTile(
                title: Text(student.fullName),
                subtitle: Text('@${student.username}'),
                onTap: () {
                  widget.onCreateDirectMessage(student.username, widget.selectedCourseId ?? 'default');
                  Navigator.pop(dialogContext);
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _showAddParticipantDialog(ChatRoom room) {
    if (room.type != ChatRoomType.group) return;
    
    final availableToAdd = widget.availableStudents.where((student) =>
      !room.participants.contains(student.username)
    ).toList();
    
    if (availableToAdd.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No more students available to add')),
      );
      return;
    }

    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Add Participants to ${_dmDisplayName(room, widget.currentUser.username, [widget.currentUser, ...widget.availableStudents])}'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: availableToAdd.length,
            itemBuilder: (context, index) {
              final student = availableToAdd[index];
              return ListTile(
                title: Text(student.fullName),
                subtitle: Text('@${student.username}'),
                onTap: () {
                  widget.onAddParticipantToGroup(room.id, student.username);
                  Navigator.pop(dialogContext);
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Sync _selectedRoom with parent's updated rooms
    if (_selectedRoom != null) {
      final updatedRoom = widget.chatRooms.firstWhere(
        (room) => room.id == _selectedRoom!.id,
        orElse: () => _selectedRoom!,
      );
      // Update if the room object changed (e.g., lastMessage updated)
      if (updatedRoom.lastMessage != _selectedRoom!.lastMessage) {
        _selectedRoom = updatedRoom;
      }
    }

    // Compute room messages fresh on every build
    final roomMessages = _selectedRoom != null 
        ? widget.messages.where((msg) => msg.courseId == _selectedRoom!.id).toList()
        : <ChatMessage>[];

    // Restrict chat for teachers
    if (widget.currentUser.role != 'Student') {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.chat_bubble_outline, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text(
              'Chat is available for students only',
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        // Chat Rooms Header
        Container(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  'Student Chat',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: kPrimaryRose,
                  ),
                ),
              ),
              PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'create_group') {
                    _showCreateGroupDialog();
                  } else if (value == 'dm_student') {
                    _showDMStudentDialog();
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'create_group',
                    child: Row(
                      children: [
                        Icon(Icons.group_add),
                        SizedBox(width: 8),
                        Text('Create Group'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'dm_student',
                    child: Row(
                      children: [
                        Icon(Icons.person_add),
                        SizedBox(width: 8),
                        Text('Direct Message'),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        
        // Chat Rooms List
        Expanded(
          flex: 2,
          child: Container(
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: Colors.grey.shade300)),
            ),
            child: widget.chatRooms.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.chat_bubble_outline, size: 48, color: Colors.grey),
                        SizedBox(height: 16),
                        Text(
                          'No chat rooms yet',
                          style: TextStyle(color: Colors.grey),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Create a group or start a direct message',
                          style: TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: widget.chatRooms.length,
                    itemBuilder: (context, index) {
                      final room = widget.chatRooms[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: kPrimaryRose.withValues(alpha: 0.1),
                            child: Icon(
                              room.type == ChatRoomType.group ? Icons.group : Icons.person,
                              color: kPrimaryRose,
                            ),
                          ),
                          title: Text(_dmDisplayName(room, widget.currentUser.username, [widget.currentUser, ...widget.availableStudents])),
                          subtitle: Text(
                            room.type == ChatRoomType.group 
                                ? '${room.participants.length} participants'
                                : 'Direct message',
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (room.lastMessage != null)
                                Text(
                                  _formatTime(room.lastMessage!.time),
                                  style: TextStyle(
                                    color: Colors.grey.shade500,
                                    fontSize: 12,
                                  ),
                                ),
                              if (room.type == ChatRoomType.group)
                                IconButton(
                                  icon: const Icon(Icons.person_add, size: 16),
                                  onPressed: () => _showAddParticipantDialog(room),
                                  tooltip: 'Add Participants',
                                ),
                            ],
                          ),
                          onTap: () => _showChatRoom(room),
                        ),
                      );
                    },
                  ),
          ),
        ),
        
        // Messages Area (when a room is selected) – full-screen overlay style
        if (_selectedRoom != null) ...[
          Expanded(
            flex: 5,
            child: Container(
              color: const Color(0xFFF5F5F5),
              child: Column(
                children: [
                  // Room Header – back arrow + centered avatar + name
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.only(top: 8, bottom: 12),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () => setState(() => _selectedRoom = null),
                          icon: const Icon(Icons.arrow_back_ios_new, size: 20),
                          color: Colors.black87,
                        ),
                        Expanded(
                          child: Column(
                            children: [
                              CircleAvatar(
                                radius: 22,
                                backgroundColor: kPrimaryRose.withValues(alpha: 0.15),
                                child: Text(
                                  _dmDisplayName(_selectedRoom!, widget.currentUser.username,
                                    [widget.currentUser, ...widget.availableStudents])
                                    .isNotEmpty
                                    ? _dmDisplayName(_selectedRoom!, widget.currentUser.username,
                                        [widget.currentUser, ...widget.availableStudents])[0]
                                        .toUpperCase()
                                    : '?',
                                  style: const TextStyle(
                                    color: kPrimaryRose,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _dmDisplayName(_selectedRoom!, widget.currentUser.username,
                                  [widget.currentUser, ...widget.availableStudents]),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 48), // balance the back button
                      ],
                    ),
                  ),

                  // Messages list
                  Expanded(
                    child: ListView.builder(
                      controller: _scrollCtrl,
                      reverse: true,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      itemCount: roomMessages.length,
                      itemBuilder: (context, i) {
                        final actualIndex = roomMessages.length - 1 - i;
                        final msg = roomMessages[actualIndex];
                        final mine = msg.sender == widget.currentUser.fullName;

                        // Avatar initial for the other person
                        final initials = msg.sender.isNotEmpty ? msg.sender[0].toUpperCase() : '?';

                        return GestureDetector(
                          key: ValueKey('room-msg-${msg.time.millisecondsSinceEpoch}'),
                          onLongPress: mine ? () => _deleteRoomMessage(msg) : null,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 3),
                            child: Row(
                              mainAxisAlignment:
                                  mine ? MainAxisAlignment.end : MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                // Avatar for received messages
                                if (!mine) ...[
                                  CircleAvatar(
                                    radius: 16,
                                    backgroundColor: Colors.grey.shade300,
                                    child: Text(
                                      initials,
                                      style: const TextStyle(fontSize: 12, color: Colors.black54),
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                ],
                                // Bubble
                                Flexible(
                                  child: Container(
                                    constraints: BoxConstraints(
                                      maxWidth: MediaQuery.of(context).size.width * 0.65,
                                    ),
                                    decoration: BoxDecoration(
                                      color: mine
                                          ? const Color(0xFFE8E8E8)
                                          : const Color(0xFF4CAF50),
                                      borderRadius: BorderRadius.only(
                                        topLeft: const Radius.circular(18),
                                        topRight: const Radius.circular(18),
                                        bottomLeft: Radius.circular(mine ? 18 : 4),
                                        bottomRight: Radius.circular(mine ? 4 : 18),
                                      ),
                                    ),
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                    child: Column(
                                      crossAxisAlignment: mine
                                          ? CrossAxisAlignment.end
                                          : CrossAxisAlignment.start,
                                      children: [
                                        if (msg.attachmentKind != null) ...[
                                          _AttachmentPreview(message: msg),
                                          const SizedBox(height: 4),
                                        ],
                                        if (msg.content.trim().isNotEmpty)
                                          Text(
                                            msg.content,
                                            style: TextStyle(
                                              color: mine ? Colors.black87 : Colors.white,
                                              fontSize: 14.5,
                                            ),
                                          ),
                                        const SizedBox(height: 2),
                                        Text(
                                          _formatTime(msg.time),
                                          style: TextStyle(
                                            color: mine
                                                ? Colors.black38
                                                : Colors.white70,
                                            fontSize: 10.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                // Spacer for sent messages (no avatar)
                                if (mine) const SizedBox(width: 6),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                  // Input bar
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
                    child: SafeArea(
                      top: false,
                      child: Row(
                        children: [
                          // + button for attachments
                          GestureDetector(
                            onTap: _pickAttachment,
                            child: Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.grey.shade400),
                              ),
                              child: const Icon(Icons.add, size: 20, color: Colors.black54),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Text field
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(0xFFF0F0F0),
                                borderRadius: BorderRadius.circular(24),
                              ),
                              child: TextField(
                                controller: _ctrl,
                                onChanged: (_) => setState(() {}),
                                textCapitalization: TextCapitalization.sentences,
                                decoration: const InputDecoration(
                                  hintText: 'Type a message...',
                                  hintStyle: TextStyle(color: Colors.black38),
                                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                  border: InputBorder.none,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Send arrow button
                          GestureDetector(
                            onTap: _selectedRoom != null && _ctrl.text.trim().isNotEmpty
                                ? () {
                                    widget.onSendMessageToRoom(_ctrl.text, _selectedRoom!.id);
                                    _ctrl.clear();
                                    setState(() {});
                                    _scrollToBottom();
                                  }
                                : null,
                            child: Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _ctrl.text.trim().isNotEmpty
                                    ? kPrimaryRose
                                    : Colors.grey.shade300,
                              ),
                              child: Icon(
                                Icons.send,
                                size: 18,
                                color: _ctrl.text.trim().isNotEmpty
                                    ? Colors.white
                                    : Colors.black38,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ],
    );
  }

  void _scrollToBottom() {
    if (!_scrollCtrl.hasClients) return;
    _scrollCtrl.animateTo(
      0.0,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
    );
  }

  Future<void> _showEmojiPicker() async {
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          child: SizedBox(
            height: 360,
            child: EmojiPicker(
              onEmojiSelected: (category, emoji) {
                _ctrl.text = '${_ctrl.text}${emoji.emoji}';
                _ctrl.selection = TextSelection.collapsed(
                  offset: _ctrl.text.length,
                );
              },
            ),
          ),
        );
      },
    );
  }

  Future<void> _pickAttachment() async {
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.image_outlined),
                title: const Text('Pick Image'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _pickImage();
                },
              ),
              ListTile(
                leading: const Icon(Icons.insert_drive_file_outlined),
                title: const Text('Pick File'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _pickFile();
                },
              ),
              ListTile(
                leading: const Icon(Icons.menu_book_outlined),
                title: const Text('Send Lesson'),
                subtitle: const Text('Share a lesson from your courses'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _pickLesson();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _pickLesson() {
    if (_selectedRoom == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please open a chat room first')),
      );
      return;
    }
    if (widget.libraryItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No lessons available to share')),
      );
      return;
    }

    // Group items by course
    final Map<String, List<LibraryItem>> byCourse = {};
    for (final item in widget.libraryItems) {
      byCourse.putIfAbsent(item.courseId, () => []).add(item);
    }

    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.6,
          minChildSize: 0.4,
          maxChildSize: 0.9,
          builder: (ctx, scrollCtrl) {
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  child: Text(
                    'Select a Lesson to Share',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: ListView(
                    controller: scrollCtrl,
                    children: byCourse.entries.map((entry) {
                      final courseId = entry.key;
                      final items = entry.value;
                      final course = widget.courses.firstWhere(
                        (c) => c.id == courseId,
                        orElse: () => Course(id: courseId, name: courseId, description: '', teacherId: ''),
                      );
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                            child: Text(
                              course.name,
                              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                                color: kPrimaryRose,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          ...items.map((item) => ListTile(
                            leading: const Icon(Icons.menu_book, color: kPrimaryRose),
                            title: Text(item.title),
                            subtitle: Text(
                              item.content.length > 60 ? '${item.content.substring(0, 60)}...' : item.content,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            onTap: () {
                              Navigator.pop(sheetContext);
                              // Determine recipient name for transaction log
                              final allUsers = [widget.currentUser, ...widget.availableStudents];
                              final recipientName = _dmDisplayName(
                                _selectedRoom!,
                                widget.currentUser.username,
                                allUsers,
                              );
                              widget.onShareLessonFromChat(item, _selectedRoom!.id, recipientName);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Lesson "${item.title}" shared!')),
                              );
                            },
                          )),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _pickImage() async {
    final picked = await _imagePicker.pickImage(source: ImageSource.gallery);
    if (!mounted || picked == null) return;
    final bytes = await picked.readAsBytes();
    
    if (_selectedRoom != null) {
      widget.onSendAttachmentToRoom(
        caption: _ctrl.text,
        kind: ChatAttachmentKind.image,
        path: picked.path,
        name: picked.name,
        bytes: bytes,
        roomId: _selectedRoom!.id,
      );
    } else {
      widget.onSendAttachment(
        caption: _ctrl.text,
        kind: ChatAttachmentKind.image,
        path: picked.path,
        name: picked.name,
        bytes: bytes,
      );
    }
    _ctrl.clear();
    _scrollToBottom();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(withData: false);
    if (!mounted || result == null || result.files.isEmpty) return;
    final file = result.files.first;
    final path = file.path;
    if (path == null) return;
    
    if (_selectedRoom != null) {
      widget.onSendAttachmentToRoom(
        caption: _ctrl.text,
        kind: ChatAttachmentKind.file,
        path: path,
        name: file.name,
        roomId: _selectedRoom!.id,
      );
    } else {
      widget.onSendAttachment(
        caption: _ctrl.text,
        kind: ChatAttachmentKind.file,
        path: path,
        name: file.name,
      );
    }
    _ctrl.clear();
    _scrollToBottom();
  }
}

class CalendarTab extends StatefulWidget {
  const CalendarTab({
    super.key,
    required this.user,
    required this.events,
    required this.onAddEvent,
    required this.onUpdateEvent,
    required this.onDeleteEvent,
  });

  final EduUser user;
  final List<CalendarEvent> events;
  final void Function(String title, String description, DateTime date)
  onAddEvent;
  final void Function(
    int index,
    String title,
    String description,
    DateTime date,
  )
  onUpdateEvent;
  final void Function(int index) onDeleteEvent;

  @override
  State<CalendarTab> createState() => _CalendarTabState();
}

class _CalendarTabState extends State<CalendarTab> {
  DateTime selectedDay = DateTime.now();
  DateTime focusedDay = DateTime.now();
  
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController();
    _descriptionController = TextEditingController();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final todayEvents = widget.events.asMap().entries.where(
      (entry) => _isSameDay(entry.value.date, selectedDay),
    ).toList();
    
    final upcomingEvents = widget.events
        .where((e) => e.date.isAfter(DateTime.now()))
        .toList()
        ..sort((a, b) => a.date.compareTo(b.date));

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
            color: Theme.of(context).colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Create Event',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  FilledButton.icon(
                    onPressed: _showAddEventDialog,
                    icon: const Icon(Icons.add),
                    label: const Text('Add New Event'),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Calendar', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 12),
                TableCalendar<CalendarEvent>(
                  firstDay: DateTime(2020),
                  lastDay: DateTime(2050),
                  focusedDay: focusedDay,
                  selectedDayPredicate: (day) => _isSameDay(day, selectedDay),
                  eventLoader: (day) {
                    try {
                      if (!mounted) return [];
                      final events = widget.events
                          .where((e) => _isSameDay(e.date, day))
                          .toList();
                      return events;
                    } catch (e) {
                      return [];
                    }
                  },
                  onDaySelected: (selected, focused) {
                    if (mounted) {
                      setState(() {
                        selectedDay = selected;
                        focusedDay = focused;
                      });
                    }
                  },
                  onPageChanged: (focused) {
                    if (mounted) {
                      focusedDay = focused;
                    }
                  },
                  headerStyle: const HeaderStyle(
                    formatButtonVisible: false,
                    titleCentered: true,
                  ),
                  calendarStyle: CalendarStyle(
                    todayDecoration: BoxDecoration(
                      color: const Color.fromRGBO(164, 92, 92, 0.4),
                      shape: BoxShape.circle,
                    ),
                    selectedDecoration: const BoxDecoration(
                      color: kPrimaryRose,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Events on ${_formatDate(selectedDay)}',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                if (todayEvents.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(8),
                    child: Text(
                      'No events scheduled for this day.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.outline,
                      ),
                    ),
                  )
                else
                  ...todayEvents.map((entry) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: kPrimaryRose.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(
                            Icons.event_note,
                            color: kPrimaryRose,
                          ),
                        ),
                        title: Text(entry.value.title),
                        subtitle: Text(entry.value.description),
                        trailing: PopupMenuButton<String>(
                                onSelected: (value) {
                                  if (value == 'edit') {
                                    _showEditEventDialog(entry.key, entry.value);
                                  } else if (value == 'delete') {
                                    widget.onDeleteEvent(entry.key);
                                  }
                                },
                                itemBuilder: (context) => const [
                                  PopupMenuItem(
                                    value: 'edit',
                                    child: Text('Edit'),
                                  ),
                                  PopupMenuItem(
                                    value: 'delete',
                                    child: Text('Delete'),
                                  ),
                                ],
                              ),
                      ),
                    );
                  }),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Upcoming Events',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                if (upcomingEvents.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(8),
                    child: Text(
                      'No upcoming events.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.outline,
                      ),
                    ),
                  )
                else
                  ...upcomingEvents.take(5).map((event) {
                    final daysAway = event.date.difference(DateTime.now()).inDays;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.blue.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            Icons.schedule,
                            color: Colors.blue.shade700,
                          ),
                        ),
                        title: Text(event.title),
                        subtitle: Text(
                          '${_formatDate(event.date)} (${daysAway > 0 ? 'in $daysAway days' : 'today'})',
                        ),
                      ),
                    );
                  }),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _showAddEventDialog() async {
    // Clear controllers before use
    _titleController.clear();
    _descriptionController.clear();
    
    if (!mounted) return;
    
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Add Calendar Event'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Title'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _descriptionController,
              decoration: const InputDecoration(labelText: 'Description'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final title = _titleController.text.trim();
              final description = _descriptionController.text.trim();
              if (title.isNotEmpty && description.isNotEmpty) {
                Navigator.of(dialogContext).pop(true);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (!mounted) return;

    final newTitle = _titleController.text.trim();
    final newDesc = _descriptionController.text.trim();

    if (result == true && newTitle.isNotEmpty && newDesc.isNotEmpty) {
      widget.onAddEvent(
        newTitle,
        newDesc,
        selectedDay,
      );
    }
  }

  Future<void> _showEditEventDialog(int index, CalendarEvent event) async {
    // Set controllers with existing event data
    _titleController.text = event.title;
    _descriptionController.text = event.description;
    DateTime pickedDate = event.date;

    if (!mounted) return;

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('Edit Event'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _descriptionController,
                decoration: const InputDecoration(labelText: 'Description'),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: Text(_formatDate(pickedDate))),
                  TextButton(
                    onPressed: () async {
                      final date = await showDatePicker(
                        context: context,
                        initialDate: pickedDate,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2050),
                      );
                      if (date != null) setLocal(() => pickedDate = date);
                    },
                    child: const Text('Pick Date'),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                final title = _titleController.text.trim();
                final description = _descriptionController.text.trim();
                if (title.isNotEmpty && description.isNotEmpty) {
                  Navigator.of(dialogContext).pop(true);
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );

    if (!mounted) return;

    final newTitle = _titleController.text.trim();
    final newDesc = _descriptionController.text.trim();

    if (result == true && newTitle.isNotEmpty && newDesc.isNotEmpty) {
      widget.onUpdateEvent(
        index,
        newTitle,
        newDesc,
        pickedDate,
      );
    }
  }
}

class LessonPlanTab extends StatefulWidget {
  const LessonPlanTab({
    super.key,
    required this.user,
    required this.lessonPlans,
    required this.onCreateLessonPlan,
    required this.onUpdateLessonPlan,
    required this.onDeleteLessonPlan,
    required this.onShareToChat,
  });

  final EduUser user;
  final List<LessonPlan> lessonPlans;
  final void Function(String title, String description, DateTime date)
  onCreateLessonPlan;
  final void Function(
    int index,
    String title,
    String description,
    DateTime date,
  )
  onUpdateLessonPlan;
  final void Function(int index) onDeleteLessonPlan;
  final void Function(LessonPlan lesson) onShareToChat;

  @override
  State<LessonPlanTab> createState() => _LessonPlanTabState();
}

class _LessonPlanTabState extends State<LessonPlanTab> {
  DateTime date = DateTime.now();
  final titleCtrl = TextEditingController();
  final descCtrl = TextEditingController();

  @override
  void dispose() {
    titleCtrl.dispose();
    descCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Create Lesson Plan',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                if (widget.user.role != 'Teacher')
                  const Text('Only teachers can create lesson plans.')
                else ...[
                  TextField(
                    controller: titleCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Lesson title',
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: descCtrl,
                    decoration: const InputDecoration(labelText: 'Description'),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: Text('Date: ${_formatDate(date)}')),
                      TextButton(
                        onPressed: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: date,
                            firstDate: DateTime(2020),
                            lastDate: DateTime(2050),
                          );
                          if (!mounted) return;
                          if (picked != null) setState(() => date = picked);
                        },
                        child: Text('Selected ${_formatDate(date)}'),
                      ),
                    ],
                  ),
                  FilledButton(
                    onPressed: () {
                      widget.onCreateLessonPlan(
                        titleCtrl.text,
                        descCtrl.text,
                        date,
                      );
                      titleCtrl.clear();
                      descCtrl.clear();
                    },
                    child: const Text('Save Lesson Plan'),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'All Lesson Plans',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 6),
                if (widget.lessonPlans.isEmpty)
                  const Text('No lesson plans yet.')
                else
                  ...widget.lessonPlans.asMap().entries.map(
                    (entry) => ListTile(
                      leading: const Icon(Icons.auto_stories_outlined),
                      title: Text(entry.value.title),
                      subtitle: Text(
                        '${entry.value.description}\n${_formatDate(entry.value.date)} - ${entry.value.createdBy}',
                      ),
                      trailing: Wrap(
                        spacing: 4,
                        children: [
                          IconButton(
                            tooltip: 'Share to chat',
                            onPressed: () => widget.onShareToChat(entry.value),
                            icon: const Icon(Icons.send_outlined),
                          ),
                          if (widget.user.role == 'Teacher')
                            PopupMenuButton<String>(
                              onSelected: (value) {
                                if (value == 'edit') {
                                  _showEditLesson(entry.key, entry.value);
                                } else if (value == 'delete') {
                                  widget.onDeleteLessonPlan(entry.key);
                                }
                              },
                              itemBuilder: (context) => const [
                                PopupMenuItem(
                                  value: 'edit',
                                  child: Text('Edit'),
                                ),
                                PopupMenuItem(
                                  value: 'delete',
                                  child: Text('Delete'),
                                ),
                              ],
                            ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _showEditLesson(int index, LessonPlan plan) async {
    final title = TextEditingController(text: plan.title);
    final desc = TextEditingController(text: plan.description);
    DateTime editDate = plan.date;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('Edit Lesson Plan'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: title),
              TextField(controller: desc),
              Row(
                children: [
                  Expanded(child: Text(_formatDate(editDate))),
                  TextButton(
                    onPressed: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: editDate,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2050),
                      );
                      if (!mounted) return;
                      if (picked != null) setLocal(() => editDate = picked);
                    },
                    child: const Text('Pick Date'),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                widget.onUpdateLessonPlan(
                  index,
                  title.text,
                  desc.text,
                  editDate,
                );
                Navigator.pop(dialogContext);
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
    title.dispose();
    desc.dispose();
  }
}

class ProfileTab extends StatefulWidget {
  const ProfileTab({
    super.key,
    required this.user,
    required this.onLogout,
    required this.onSave,
  });

  final EduUser user;
  final VoidCallback onLogout;
  final void Function({
    required String fullName,
    required String email,
    required String bio,
    Uint8List? avatarBytes,
    String? gender,
    String? birthday,
    String? address,
  })
  onSave;

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  late final TextEditingController nameCtrl;
  late final TextEditingController emailCtrl;
  late final TextEditingController bioCtrl;
  late final TextEditingController _genderCtrl;
  late final TextEditingController _birthdayCtrl;
  late final TextEditingController _addressCtrl;
  final _imagePicker = ImagePicker();
  Uint8List? _avatarBytes;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    nameCtrl = TextEditingController(text: widget.user.fullName);
    emailCtrl = TextEditingController(text: widget.user.email);
    bioCtrl = TextEditingController(text: widget.user.bio);
    _genderCtrl = TextEditingController(text: widget.user.gender);
    _birthdayCtrl = TextEditingController(text: widget.user.birthday);
    _addressCtrl = TextEditingController(text: widget.user.address);
    _avatarBytes = widget.user.avatarBytes;
  }

  @override
  void didUpdateWidget(ProfileTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.user != widget.user) {
      nameCtrl.text = widget.user.fullName;
      emailCtrl.text = widget.user.email;
      bioCtrl.text = widget.user.bio;
      _genderCtrl.text = widget.user.gender;
      _birthdayCtrl.text = widget.user.birthday;
      _addressCtrl.text = widget.user.address;
      _avatarBytes = widget.user.avatarBytes;
    }
  }

  @override
  void dispose() {
    nameCtrl.dispose();
    emailCtrl.dispose();
    bioCtrl.dispose();
    _genderCtrl.dispose();
    _birthdayCtrl.dispose();
    _addressCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _isEditing ? _buildEditView(context) : _buildInfoView(context);
  }

  Widget _buildInfoView(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 16),
            CircleAvatar(
              radius: 56,
              backgroundColor: const Color(0xFFD4A5A5),
              backgroundImage: _avatarBytes != null ? MemoryImage(_avatarBytes!) : null,
              child: _avatarBytes == null
                  ? Text(
                      widget.user.fullName.characters.first.toUpperCase(),
                      style: const TextStyle(fontSize: 40, color: Colors.white),
                    )
                  : null,
            ),
            const SizedBox(height: 24),
            const Text(
              'Personal Information',
              style: TextStyle(
                fontFamily: 'AlegreyaSC',
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Color(0xFF5A3A3A),
              ),
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFF5EDED),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _infoRow('Full Name:', widget.user.fullName),
                  _infoRow('ID Number:', widget.user.username),
                  _infoRow('Email:', widget.user.email),
                  _infoRow('Phone Number:', widget.user.bio.isNotEmpty ? widget.user.bio : '—'),
                  _infoRow('Gender:', widget.user.gender.isNotEmpty ? widget.user.gender : '—'),
                  _infoRow('Birthday:', widget.user.birthday.isNotEmpty ? widget.user.birthday : '—'),
                  _infoRow('Address:', widget.user.address.isNotEmpty ? widget.user.address : '—'),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => setState(() => _isEditing = true),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFA45C5C),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text('Edit Profile', style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontSize: 14, color: Color(0xFF5A3A3A)),
          children: [
            TextSpan(text: '$label ', style: const TextStyle(fontWeight: FontWeight.bold)),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }

  Widget _buildEditView(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Center(
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 56,
                    backgroundColor: const Color(0xFFD4A5A5),
                    backgroundImage: _avatarBytes != null ? MemoryImage(_avatarBytes!) : null,
                    child: _avatarBytes == null
                        ? Text(
                            widget.user.fullName.characters.first.toUpperCase(),
                            style: const TextStyle(fontSize: 40, color: Colors.white),
                          )
                        : null,
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: GestureDetector(
                      onTap: _pickAvatar,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: const BoxDecoration(
                          color: Color(0xFFA45C5C),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.camera_alt, color: Colors.white, size: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Personal Information',
              style: TextStyle(
                fontFamily: 'AlegreyaSC',
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Color(0xFF5A3A3A),
              ),
            ),
            const SizedBox(height: 16),
            _editField('Full Name', nameCtrl),
            _editField('ID Number', TextEditingController(text: widget.user.username)..selection = TextSelection.collapsed(offset: widget.user.username.length)),
            _editField('Email', emailCtrl),
            _editField('Phone Number', bioCtrl),
            _editField('Gender', _genderCtrl),
            _editField('Birthday', _birthdayCtrl),
            _editField('Address', _addressCtrl),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  widget.onSave(
                    fullName: nameCtrl.text,
                    email: emailCtrl.text,
                    bio: bioCtrl.text,
                    avatarBytes: _avatarBytes,
                    gender: _genderCtrl.text,
                    birthday: _birthdayCtrl.text,
                    address: _addressCtrl.text,
                  );
                  setState(() => _isEditing = false);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Profile updated.')),
                  );
                },
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFA45C5C),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text('Done', style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _editField(String label, TextEditingController ctrl) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: ctrl,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Color(0xFF5A3A3A)),
          border: const OutlineInputBorder(),
          focusedBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: Color(0xFFA45C5C)),
          ),
          suffixIcon: const Icon(Icons.edit, size: 18, color: Color(0xFFA45C5C)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        ),
      ),
    );
  }

  Future<void> _pickAvatar() async {
    final picked = await _imagePicker.pickImage(source: ImageSource.gallery);
    if (!mounted || picked == null) return;
    final bytes = await picked.readAsBytes();
    if (!mounted) return;
    setState(() => _avatarBytes = bytes);
  }
}

class TransactionsTab extends StatelessWidget {
  const TransactionsTab({
    super.key,
    required this.currentUser,
    required this.noteTransactions,
  });

  final EduUser currentUser;
  final List<NoteTransaction> noteTransactions;

  @override
  Widget build(BuildContext context) {
    if (noteTransactions.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.receipt_long_outlined, size: 64, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            Text(
              'No transactions yet',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Text(
              'Share a lesson in chat to see it here',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    // Group by date label
    final Map<String, List<NoteTransaction>> grouped = {};
    final now = DateTime.now();
    for (final txn in noteTransactions) {
      final diff = DateTime(now.year, now.month, now.day)
          .difference(DateTime(txn.time.year, txn.time.month, txn.time.day))
          .inDays;
      String label;
      if (diff == 0) {
        label = 'Recent';
      } else if (diff == 1) {
        label = 'Yesterday';
      } else {
        label = _formatTxnDate(txn.time);
      }
      grouped.putIfAbsent(label, () => []).add(txn);
    }

    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 12),
      children: grouped.entries.map((entry) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text(
                entry.key,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            ...entry.value.map((txn) {
              final isSent = txn.sharedBy == currentUser.fullName;
              final otherPerson = isSent ? txn.sharedWith : txn.sharedBy;
              final description = isSent
                  ? 'You have shared your ${txn.courseName} notes with $otherPerson.'
                  : '$otherPerson has shared their ${txn.courseName} notes with you.';
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: kPrimaryRose.withValues(alpha: 0.15),
                  child: Text(
                    otherPerson.isNotEmpty ? otherPerson[0].toUpperCase() : '?',
                    style: const TextStyle(color: kPrimaryRose, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text(description, style: const TextStyle(fontSize: 13.5)),
                trailing: Text(
                  _formatTxnTime(txn.time),
                  style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              );
            }),
          ],
        );
      }).toList(),
    );
  }

  String _formatTxnDate(DateTime dt) {
    const months = [
      '', 'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return '${months[dt.month]} ${dt.day}';
  }

  String _formatTxnTime(DateTime dt) {
    final h = dt.hour > 12 ? dt.hour - 12 : (dt.hour == 0 ? 12 : dt.hour);
    final m = dt.minute.toString().padLeft(2, '0');
    final ampm = dt.hour >= 12 ? 'PM' : 'AM';
    return '$h:$m $ampm';
  }
}

class AnnouncementTab extends StatefulWidget {
  const AnnouncementTab({
    super.key,
    required this.user,
    required this.announcements,
    required this.onCreateAnnouncement,
    required this.onUpdateAnnouncement,
    required this.onDeleteAnnouncement,
  });

  final EduUser user;
  final List<Announcement> announcements;
  final void Function(String title, String content, {bool? isPinned}) onCreateAnnouncement;
  final void Function(int index, String title, String content, {bool? isPinned}) onUpdateAnnouncement;
  final void Function(int index) onDeleteAnnouncement;

  @override
  State<AnnouncementTab> createState() => _AnnouncementTabState();
}

class _AnnouncementTabState extends State<AnnouncementTab> {
  final titleCtrl = TextEditingController();
  final contentCtrl = TextEditingController();
  bool isPinned = false;

  @override
  void dispose() {
    titleCtrl.dispose();
    contentCtrl.dispose();
    super.dispose();
  }

  void _createAnnouncement() {
    final title = titleCtrl.text.trim();
    final content = contentCtrl.text.trim();
    
    if (title.isNotEmpty && content.isNotEmpty) {
      widget.onCreateAnnouncement(title, content, isPinned: isPinned);
      titleCtrl.clear();
      contentCtrl.clear();
      setState(() => isPinned = false);
    }
  }

  void _showEditDialog(int index, Announcement announcement) {
    titleCtrl.text = announcement.title;
    contentCtrl.text = announcement.content;
    isPinned = announcement.isPinned;

    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Edit Announcement'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleCtrl,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: contentCtrl,
                decoration: const InputDecoration(labelText: 'Content'),
                maxLines: 5,
              ),
              const SizedBox(height: 8),
              CheckboxListTile(
                title: const Text('Pin this announcement'),
                value: isPinned,
                onChanged: (value) => setState(() => isPinned = value ?? false),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              widget.onUpdateAnnouncement(
                index,
                titleCtrl.text.trim(),
                contentCtrl.text.trim(),
                isPinned: isPinned,
              );
              Navigator.pop(dialogContext);
              titleCtrl.clear();
              contentCtrl.clear();
              setState(() => isPinned = false);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (widget.user.role == 'Teacher')
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Create Announcement',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: titleCtrl,
                    decoration: const InputDecoration(labelText: 'Title'),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: contentCtrl,
                    decoration: const InputDecoration(labelText: 'Content'),
                    maxLines: 4,
                  ),
                  const SizedBox(height: 8),
                  CheckboxListTile(
                    title: const Text('Pin this announcement'),
                    value: isPinned,
                    onChanged: (value) => setState(() => isPinned = value ?? false),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _createAnnouncement,
                    icon: const Icon(Icons.campaign),
                    label: const Text('Post Announcement'),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 16),
        ...widget.announcements.asMap().entries.map((entry) {
          final index = entry.key;
          final announcement = entry.value;
          
          return Card(
            color: announcement.isPinned 
                ? kPrimaryRose.withValues(alpha: 0.1) 
                : null,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (announcement.isPinned)
                        Icon(Icons.push_pin, size: 16, color: kPrimaryRose),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          announcement.title,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: announcement.isPinned 
                                ? FontWeight.bold 
                                : FontWeight.normal,
                          ),
                        ),
                      ),
                      if (widget.user.role == 'Teacher')
                        PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'edit') {
                              _showEditDialog(index, announcement);
                            } else if (value == 'delete') {
                              widget.onDeleteAnnouncement(index);
                            } else if (value == 'togglePin') {
                              widget.onUpdateAnnouncement(
                                index,
                                announcement.title,
                                announcement.content,
                                isPinned: !announcement.isPinned,
                              );
                            }
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(value: 'edit', child: Text('Edit')),
                            const PopupMenuItem(value: 'delete', child: Text('Delete')),
                            PopupMenuItem(
                              value: 'togglePin',
                              child: Text(announcement.isPinned ? 'Unpin' : 'Pin'),
                            ),
                          ],
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(announcement.content),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Icon(Icons.person, size: 16),
                      const SizedBox(width: 4),
                      Text(announcement.createdBy),
                      const Spacer(),
                      Icon(Icons.schedule, size: 16),
                      const SizedBox(width: 4),
                      Text(_formatDate(announcement.date)),
                    ],
                  ),
                ],
              ),
            ),
          );
        }),
        if (widget.announcements.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                children: [
                  Icon(
                    Icons.campaign_outlined,
                    size: 48,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No announcements yet',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.user.role == 'Teacher'
                        ? 'Create your first announcement above!'
                        : 'Wait for teachers to post announcements.',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class LibraryTab extends StatefulWidget {
  const LibraryTab({
    super.key,
    required this.user,
    required this.libraryItems,
    required this.onAddLibraryItem,
    required this.onUpdateLibraryItem,
    required this.onToggleLibraryItemToDo,
    required this.onDeleteLibraryItem,
    required this.chatRooms,
    required this.onShareLibraryItemToRoom,
  });

  final EduUser user;
  final List<LibraryItem> libraryItems;
  final void Function(String title, String content) onAddLibraryItem;
  final void Function(int index, {String? title, String? content, int? color, String? fontFamily, int? backgroundColor}) onUpdateLibraryItem;
  final void Function(int index) onToggleLibraryItemToDo;
  final void Function(int index) onDeleteLibraryItem;
  final List<ChatRoom> chatRooms;
  final void Function(LibraryItem item, String roomId) onShareLibraryItemToRoom;

  @override
  State<LibraryTab> createState() => _LibraryTabState();
}

class _LibraryTabState extends State<LibraryTab> {
  final titleCtrl = TextEditingController();
  final contentCtrl = TextEditingController();

  @override
  void dispose() {
    titleCtrl.dispose();
    contentCtrl.dispose();
    super.dispose();
  }

  void _addLibraryItem() {
    final title = titleCtrl.text.trim();
    final content = contentCtrl.text.trim();
    if (title.isEmpty || content.isEmpty) return;
    
    widget.onAddLibraryItem(title, content);
    titleCtrl.clear();
    contentCtrl.clear();
  }

  void _showLibraryItemMenu(BuildContext context, int index, LibraryItem item) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header matching screenshot style
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: const BoxDecoration(
              color: Color(0xFFA45C5C),
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Row(
              children: [
                const Icon(Icons.folder, color: Colors.white, size: 28),
                const SizedBox(width: 12),
                Text(
                  item.title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.share_outlined),
            title: const Text('Share'),
            onTap: () {
              Navigator.pop(ctx);
              _showShareToChatDialog(context, item);
            },
          ),
          ListTile(
            leading: const Icon(Icons.edit_outlined),
            title: const Text('Rename'),
            onTap: () {
              Navigator.pop(ctx);
              _showRenameDialog(context, index, item.title);
            },
          ),
          ListTile(
            leading: const Icon(Icons.palette_outlined),
            title: const Text('Change color'),
            onTap: () {
              Navigator.pop(ctx);
              _showBackgroundColorPicker(context, index, item.backgroundColor);
            },
          ),
          ListTile(
            leading: const Icon(Icons.text_fields),
            title: const Text('Font'),
            onTap: () {
              Navigator.pop(ctx);
              _showFontPicker(context, index, item.fontFamily);
            },
          ),
          ListTile(
            leading: const Icon(Icons.image_outlined),
            title: const Text('Background'),
            onTap: () {
              Navigator.pop(ctx);
              _showBackgroundColorPicker(context, index, item.backgroundColor);
            },
          ),
          ListTile(
            leading: const Icon(Icons.checklist_outlined),
            title: Text(item.isMarkedAsToD ? 'Remove from To Do' : 'To Do'),
            onTap: () {
              Navigator.pop(ctx);
              widget.onToggleLibraryItemToDo(index);
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline, color: Colors.red),
            title: const Text('Remove', style: TextStyle(color: Colors.red)),
            onTap: () {
              Navigator.pop(ctx);
              widget.onDeleteLibraryItem(index);
            },
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  void _showShareToChatDialog(BuildContext context, LibraryItem item) {
    if (widget.chatRooms.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No chat rooms available. Create a group or DM first.')),
      );
      return;
    }

    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Share to Chat'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Share "${item.title}" to:',
                style: const TextStyle(fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 12),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 300),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: widget.chatRooms.length,
                  itemBuilder: (_, index) {
                    final room = widget.chatRooms[index];
                    final displayName = _dmDisplayName(
                      room,
                      widget.user.username,
                      [],
                    );
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: kPrimaryRose.withValues(alpha: 0.12),
                        child: Icon(
                          room.type == ChatRoomType.group
                              ? Icons.group
                              : Icons.person,
                          color: kPrimaryRose,
                          size: 20,
                        ),
                      ),
                      title: Text(displayName),
                      subtitle: Text(
                        room.type == ChatRoomType.group
                            ? 'Group · ${room.participants.length} members'
                            : 'Direct message',
                        style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                      ),
                      onTap: () {
                        widget.onShareLibraryItemToRoom(item, room.id);
                        Navigator.pop(ctx);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Shared "${item.title}" to $displayName',
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _showRenameDialog(BuildContext context, int index, String currentTitle) {
    final renameCtrl = TextEditingController(text: currentTitle);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename'),
        content: TextField(
          controller: renameCtrl,
          decoration: const InputDecoration(labelText: 'New title'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              widget.onUpdateLibraryItem(index, title: renameCtrl.text.trim());
              Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showFontPicker(BuildContext context, int index, String currentFont) {
    final fonts = ['Default', 'AlegreyaSC', 'AlexBrush'];
    showDialog<void>(
      context: context,
      builder: (ctx) {
        String selectedFont = currentFont;
        return StatefulBuilder(
          builder: (_, setDialogState) => AlertDialog(
            title: const Text('Choose Font'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: fonts.map((font) {
                final isDefault = font == 'Default';
                final selected = isDefault ? (selectedFont == 'Default' || selectedFont.isEmpty) : font == selectedFont;
                return ListTile(
                  title: Text(
                    font,
                    style: TextStyle(fontFamily: isDefault ? null : font, fontSize: 16),
                  ),
                  leading: Icon(
                    selected ? Icons.radio_button_checked : Icons.radio_button_off,
                    color: selected ? kPrimaryRose : Colors.grey,
                  ),
                  onTap: () {
                    setDialogState(() => selectedFont = font);
                    widget.onUpdateLibraryItem(index, fontFamily: isDefault ? 'AlegreyaSC' : font);
                    Navigator.pop(ctx);
                  },
                );
              }).toList(),
            ),
          ),
        );
      },
    );
  }

  void _showBackgroundColorPicker(BuildContext context, int index, int currentBg) {
    final bgColors = <Map<String, dynamic>>[
      {'value': 0xFFFFFAF0, 'label': 'Floral White'},
      {'value': 0xFFFFF5EE, 'label': 'Seashell'},
      {'value': 0xFFFFF8DC, 'label': 'Cornsilk'},
      {'value': 0xFFFFFFF0, 'label': 'Ivory'},
      {'value': 0xFFE8F5E9, 'label': 'Mint'},
      {'value': 0xFFE3F2FD, 'label': 'Sky Blue'},
      {'value': 0xFFFCE4EC, 'label': 'Blush'},
      {'value': 0xFFF3E5F5, 'label': 'Lavender'},
      {'value': 0xFFFFF9C4, 'label': 'Lemon'},
      {'value': 0xFFFFE0B2, 'label': 'Peach'},
      {'value': 0xFFE0F7FA, 'label': 'Aqua'},
      {'value': 0xFFEFEBE9, 'label': 'Warm Gray'},
    ];

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (_, setDialogState) {
          int selected = currentBg;
          return AlertDialog(
            title: const Text('Choose Card Color'),
            content: SizedBox(
              width: double.maxFinite,
              child: GridView.count(
                crossAxisCount: 4,
                shrinkWrap: true,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                children: bgColors.map((entry) {
                  final colorVal = entry['value'] as int;
                  final label = entry['label'] as String;
                  final isSelected = selected == colorVal;
                  return GestureDetector(
                    onTap: () {
                      setDialogState(() => selected = colorVal);
                      widget.onUpdateLibraryItem(index, backgroundColor: colorVal);
                      Navigator.pop(ctx);
                    },
                    child: Tooltip(
                      message: label,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(colorVal),
                          border: isSelected
                              ? Border.all(color: kPrimaryRose, width: 3)
                              : Border.all(color: Colors.grey[400]!, width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: isSelected
                              ? [BoxShadow(color: kPrimaryRose.withValues(alpha: 0.4), blurRadius: 4)]
                              : null,
                        ),
                        child: isSelected
                            ? const Icon(Icons.check, color: Colors.black54, size: 18)
                            : null,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel'),
              ),
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Create Library Item',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: titleCtrl,
                  decoration: const InputDecoration(labelText: 'Title'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: contentCtrl,
                  decoration: const InputDecoration(labelText: 'Content/Notes'),
                  maxLines: 4,
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _addLibraryItem,
                  icon: const Icon(Icons.add),
                  label: const Text('Add to Library'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        if (widget.libraryItems.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                children: [
                  Icon(
                    Icons.library_books_outlined,
                    size: 48,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No library items yet',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Create your first library item above!',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          )
        else
          ...widget.libraryItems.asMap().entries.map((entry) {
            final index = entry.key;
            final item = entry.value;
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: Container(
                decoration: BoxDecoration(
                  color: Color(item.backgroundColor),
                  border: Border.all(color: Colors.grey.shade300, width: 1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.title,
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.grey.shade900,
                                    fontFamily: item.fontFamily,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  item.content,
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[700],
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.more_vert),
                            onPressed: () => _showLibraryItemMenu(context, index, item),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          if (item.isMarkedAsToD)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.amber[100],
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Row(
                                children: [
                                  Icon(Icons.check_box, size: 16, color: Colors.amber[700]),
                                  const SizedBox(width: 4),
                                  Text(
                                    'To Do',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.amber[700],
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SettingsTab – Switch Account, Log Out, Delete Account
// ─────────────────────────────────────────────────────────────────────────────
class SettingsTab extends StatelessWidget {
  const SettingsTab({
    super.key,
    required this.user,
    required this.onLogout,
    required this.onDeleteAccount,
  });

  final EduUser user;
  final VoidCallback onLogout;
  final VoidCallback onDeleteAccount;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 48),
            // Switch Account
            _SettingsPillButton(
              icon: Icons.people_alt_rounded,
              label: 'Switch Account',
              onTap: () => onLogout(),
            ),
            const SizedBox(height: 16),
            // Delete Account
            _SettingsPillButton(
              icon: Icons.person_remove_rounded,
              label: 'Delete Account',
              onTap: () => _confirmDelete(context),
            ),
            const SizedBox(height: 16),
            // Log Out
            _SettingsPillButton(
              icon: Icons.logout_rounded,
              label: 'Log Out',
              onTap: () => _confirmLogout(context),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmLogout(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Log Out'),
        content: const Text('Are you sure you want to log out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFA45C5C)),
            onPressed: () {
              Navigator.pop(ctx);
              onLogout();
            },
            child: const Text('Log Out'),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Account'),
        content: const Text(
          'This will permanently delete your account and all your data. This cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              Navigator.pop(ctx);
              onDeleteAccount();
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class _SettingsPillButton extends StatelessWidget {
  const _SettingsPillButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFB07070),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(32),
          ),
          elevation: 0,
        ),
        child: Row(
          children: [
            Icon(icon, size: 26, color: Colors.white),
            const SizedBox(width: 16),
            Text(
              label,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AppLogo extends StatelessWidget {
  const AppLogo({super.key, this.size = 72});
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Image.asset(
        'assets/logo.png',
        width: size,
        height: size,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) {
          // Fallback to the gradient design if image fails to load
          return Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(size * 0.28),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [kPrimaryRose, Color(0xFFB98888)],
              ),
            ),
            child: Icon(Icons.school_rounded, size: size * 0.56, color: Colors.white),
          );
        },
      ),
    );
  }
}

class UserAvatar extends StatelessWidget {
  const UserAvatar({super.key, required this.user, this.radius = 20});

  final EduUser user;
  final double radius;

  @override
  Widget build(BuildContext context) {
    if (user.avatarBytes != null && user.avatarBytes!.isNotEmpty) {
      return CircleAvatar(
        radius: radius,
        backgroundImage: MemoryImage(user.avatarBytes!),
      );
    }
    return CircleAvatar(
      radius: radius,
      child: Text(user.fullName.characters.first),
    );
  }
}

// Returns the display name for a chat room from the perspective of [currentUsername].
// For DMs stored as 'userA|userB', shows the OTHER participant's full name if possible.
String _dmDisplayName(ChatRoom room, String currentUsername, List<EduUser> allUsers) {
  if (room.type != ChatRoomType.direct) return room.name;
  final parts = room.name.split('|');
  if (parts.length != 2) return room.name; // legacy or group
  final otherUsername = parts[0] == currentUsername ? parts[1] : parts[0];
  final match = allUsers.where((u) => u.username == otherUsername).firstOrNull;
  return match?.fullName ?? otherUsername;
}

String _formatDate(DateTime date) {
  return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
}

String _formatTime(DateTime date) {
  final hour = date.hour.toString().padLeft(2, '0');
  final minute = date.minute.toString().padLeft(2, '0');
  return '$hour:$minute';
}

bool _isSameDay(DateTime a, DateTime b) {
  return a.year == b.year && a.month == b.month && a.day == b.day;
}

class _AttachmentPreview extends StatelessWidget {
  const _AttachmentPreview({required this.message});

  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final path = message.attachmentPath;
    final name = message.attachmentName ?? 'Attachment';
    final bytes = message.attachmentBytes;

    switch (message.attachmentKind) {
      case ChatAttachmentKind.image:
        if (bytes != null && bytes.isNotEmpty) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.memory(
              bytes,
              width: 220,
              height: 160,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return _FileChip(name: name);
              },
            ),
          );
        }

        // Fallback for already-stored messages that only have a path.
        if (path == null) return _FileChip(name: name);
        if (path.startsWith('content://')) return _FileChip(name: name);
        final file = File(path);
        return ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.file(
            file,
            width: 220,
            height: 160,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return _FileChip(name: name);
            },
          ),
        );
      case ChatAttachmentKind.file:
        if (path == null) return _FileChip(name: name);
        return _FileChip(name: name);
      case null:
        return const SizedBox.shrink();
    }
  }
}

class _FileChip extends StatelessWidget {
  const _FileChip({required this.name});
  final String name;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.secondaryContainer,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.insert_drive_file_outlined, size: 18),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              name,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}