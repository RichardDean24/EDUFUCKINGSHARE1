import 'package:flutter/material.dart';
import 'dart:async';
import 'app.dart';

void main() {
  runApp(const SplashWrapper());
}

class SplashWrapper extends StatelessWidget {
  const SplashWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const EduShareApp()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(174, 114, 114, 1), // kPrimaryRose
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const AppLogo(size: 220),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                const Text(
                  'EDU',
                  style: TextStyle(
                    fontFamily: 'AlegreyaSC',
                    fontSize: 64,
                    fontWeight: FontWeight.w700,
                    color: Color.fromARGB(255, 255, 255, 255),
                    letterSpacing: 1.0,
                  ),
                ),
                // 'share' with smaller 's' using RichText for visual balance
                RichText(
                  text: const TextSpan(
                    children: [
                      TextSpan(
                        text: 's',
                        style: TextStyle(
                          fontFamily: 'AlexBrush',
                          fontSize: 46,
                          fontWeight: FontWeight.w300,
                          color: Color.fromARGB(255, 255, 255, 255),
                          letterSpacing: 0.0,
                        ),
                      ),
                      TextSpan(
                        text: 'hare',
                        style: TextStyle(
                          fontFamily: 'AlexBrush',
                          fontSize: 60,
                          fontWeight: FontWeight.w300,
                          color: Color.fromARGB(255, 255, 255, 255),
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}