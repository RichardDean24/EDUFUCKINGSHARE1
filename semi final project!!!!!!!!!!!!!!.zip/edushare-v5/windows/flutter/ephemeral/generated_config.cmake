# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Flutter\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\ED PHILIP\\Desktop\\edushare" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Flutter\\flutter"
  "PROJECT_DIR=C:\\Users\\ED PHILIP\\Desktop\\edushare"
  "FLUTTER_ROOT=C:\\Flutter\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\ED PHILIP\\Desktop\\edushare\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\ED PHILIP\\Desktop\\edushare"
  "FLUTTER_TARGET=C:\\Users\\ED PHILIP\\Desktop\\edushare\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDEuNQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049MmM5ZWIyMDczOQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049MDUyZjMxZDExNQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS4z"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\ED PHILIP\\Desktop\\edushare\\.dart_tool\\package_config.json"
)
