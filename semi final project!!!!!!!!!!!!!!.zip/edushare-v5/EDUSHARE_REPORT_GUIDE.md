# EduShare — Report & Feature Guide

---

## 1. Purpose (report)

EduShare is a **course-centric education companion app**. Users sign in, select or create a **course**, then use tabs for **dashboard tasks**, **calendar**, **announcements**, **lesson plans**, and **profile**. **Students** also get **chat** and a personal **library** of notes. Data is held **in memory** while the app runs (typical for a prototype; restarting the app resets state unless you add persistence).

---

## 2. Technology


| Item             | Detail                                                                                       |
| ---------------- | -------------------------------------------------------------------------------------------- |
| Framework        | Flutter (Dart)                                                                               |
| Main UI file     | `lib/app.dart` (single-file prototype with models + screens)                                 |
| Notable packages | `table_calendar`, `percent_indicator`, `emoji_picker_flutter`, `image_picker`, `file_picker` |


---

## 3. Roles and navigation

### Roles

- **Teacher**: Can **create courses** from the app bar. Sees **Home**, **Calendar**, **Announcements**, **Lesson**, **Profile**. Does **not** see **Chat** or **Library** in the bottom bar (by design in current code).
- **Student**: Can **enroll** in a course. Sees **Home**, **Chat**, **Calendar**, **Announcements**, **Library**, **Lesson**, **Profile**.

### Course selection

The **app bar** includes a **course dropdown**. Until a course is selected, the main body shows a **placeholder** instead of tab content. This ties chat, todos, events, library, and lessons to the **active course**.

---

## 4. Features by tab

### Home (Dashboard)

- Todo list for the current user and course: add, toggle complete, edit, delete.
- Lesson-related summary/widgets as implemented in `DashboardTab`.

### Chat (students only)

- Course-scoped messaging: **rooms** (group and direct), send text, **emoji** picker, **image** and **file** attachments, delete messages where supported.
- Create group chats and DMs with participants from the course context.

### Calendar

- **Table calendar** view with course events: add, update, delete events on selected dates.

### Announcements

- **Teachers**: create announcements (optional **pin**).
- **Teachers / students**: view list; teachers can edit, delete, pin/unpin.

### Library (students only)

- Create **library items** (title + notes/content).
- Per-item menu (**⋮**):
  - **Rename**
  - **Card color** — picks a **background color** for the card (single color control; border/title use neutral styling for readability).
  - **Font** — choose between **AlegreyaSC** and **AlexBrush** (implemented with `ListTile` + radio-style icons so it works across Flutter versions without a `RadioGroup` widget).
  - **Mark as To Do** / remove from To Do
  - **Share to Chat** — send a library item into a selected chat room
  - **Remove** — delete the item

### Lesson

- Lesson plans for the course: create, update, delete; sharing to chat where wired in the parent callbacks.

### Profile

- View and edit **name**, **email**, **bio**; **upload or remove profile picture** (image picker); **log out**.

### Authentication screen

- **Log in** / **Register** flow with **email OTP verification** step (UI flow as implemented in `AuthScreen`).
- Brand row **“Edu” + “Share”** scales down on narrow widths (`FittedBox`) to avoid layout overflow on small screens and in tests.

---

## 5. Quality checks (what to show in your report)

Run from the project root (`edushare`):

```text
flutter analyze
flutter test
```

- `**flutter analyze**`: should report **No issues found** (no errors or infos treated as failures).
- `**flutter test`**: includes a smoke test that the auth screen renders (`test/widget_test.dart`).

To run the app on a device or emulator:

```text
flutter run
```

---

## 6. Implementation notes useful for documentation

- **Single main source**: Most UI and state live in `lib/app.dart` for simplicity; `main.dart` boots `EduShareApp`.
- **Font picker**: Uses `**ListTile` + `Icons.radio_button_checked` / `off`** instead of `RadioListTile`’s `groupValue` / `onChanged` or Material 3’s `RadioGroup`, so the project **compiles on older Flutter** and avoids **deprecated API** warnings on **newer Flutter** where `RadioListTile` group handling changed.
- **Library styling**: One clear **card color** control; avoids two overlapping “color” and “background” actions that confused users.
- **Library list vs storage**: The UI shows a **filtered** list (current course + current user). Actions like rename, font, color, to‑do, and delete use the item’s `**id`** to find the correct index in the global `_libraryItems` list. **Share to chat** already passed the full `LibraryItem`, so it worked even before this mapping.

---

## 7. Limitations (honest scope for a report)

- Data is **in-process** unless you add a backend or local database.
- Role and tab rules are **fixed in code** (e.g., library only for students).
- OTP and auth are **demonstration-level**; production apps need secure servers and token handling.

---

## 8. Suggested report sections

1. **Introduction** — problem (student–teacher coordination, notes, chat).
2. **Requirements** — roles, course model, functional list (mirror section 4).
3. **Design** — Flutter architecture, navigation, key widgets.
4. **Implementation** — `app.dart` structure, packages, notable UX decisions (library color, font picker).
5. **Testing** — `flutter analyze`, `flutter test`, manual test checklist (login, course select, each tab).
6. **Conclusion** — what works, what you would add next (API, persistence, push notifications).

You can paste screenshots of each tab and attach terminal output of `flutter analyze` and `flutter test` as appendices.